package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import rma.etf.unsa.ba.spirala1.R;

public class SpinnerAdapter extends ArrayAdapter<Kategorija> {

    private static class ViewHolder {
        private TextView itemView;
    }

    public SpinnerAdapter(Context context, int textViewResourceId, ArrayList<Kategorija> items) {
        super(context, textViewResourceId, items);
    }
    private View initView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(this.getContext()).inflate(R.layout.kviz_list_item, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.itemView = (TextView) convertView.findViewById(R.id.nazivKviza);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Kategorija item = (Kategorija) getItem(position);
        if (item!= null) {
            viewHolder.itemView.setText(item.getNaziv());
        }

        return convertView;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }
}