package ba.unsa.etf.rma.utilities;

public interface AsyncAddQuizTaskResponse {
    void finishedAdd(String id);
}
