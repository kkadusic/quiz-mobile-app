package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.enums.Type;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.Observer;

public class QuizesAdapter extends AsyncListAdapter<Kviz>/* implements AsyncAddQuizTaskResponse */ {

    private boolean gridLayout;
    private ViewGroup listView = null;
    private Kategorija constraint = new Kategorija("Svi", "0");
    private ba.unsa.etf.rma.utilities.Observer observer = null;

    public QuizesAdapter(@NonNull Context context, ba.unsa.etf.rma.utilities.Observer observer, ViewGroup listView) {
        super(context, 0, Type.Quiz);
        this.gridLayout = false;
        this.listView = listView;
        this.observer = observer;
    }

    public QuizesAdapter(@NonNull Context context, Observer observer, boolean gridLayout) {
        super(context, 0, Type.Quiz);
        this.observer = observer;
        this.gridLayout = gridLayout;
    }

    @Override
    public int getCount() {
        return getObjects().size();
    }

    @Override
    public Kviz getItem(int position) {
        return getObjects().get(position);
    }

    @Override
    public int getPosition(@Nullable Kviz item) {
        return getObjects().indexOf(item);
    }

    @Override
    protected ArrayList<Kviz> getObjects() {
        return Cache.getInstance(context, observer, constraint).getQuizes();
    }

    public void updateConstraint(Kategorija category) {
        this.constraint = category;
        Cache.getInstance(context, observer, constraint).update();
    }

    @Override
    protected View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            if (!gridLayout) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.lv_kviz, parent, false);
            } else {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_element_kviz, parent, false);
            }
        }

        IconView ikonaKategorije;
        TextView imeKviza;
        TextView brojPitanja = convertView.findViewById(R.id.brojPitanja);

        if (gridLayout) {
            ikonaKategorije = convertView.findViewById(R.id.icon);
            imeKviza = convertView.findViewById(R.id.nazivKviza);
            brojPitanja = convertView.findViewById(R.id.brojPitanja);
        } else {
            ikonaKategorije = convertView.findViewById(R.id.ikonaKategorije);
            imeKviza = convertView.findViewById(R.id.imeKviza);
        }

        Kviz currentItem = getItem(position);
        if (currentItem != null && currentItem.getKategorija() != null) {
            imeKviza.setText(currentItem.getNaziv());
            ikonaKategorije.setIcon(Integer.parseInt(currentItem.getKategorija().getId()));
        } else {
            ikonaKategorije.setImageResource(R.drawable.add_button);
            imeKviza.setText(R.string.dodajKviz);
        }

        if (gridLayout && currentItem != null) {
            if (currentItem.getPitanja() == null) brojPitanja.setText(0);
            else brojPitanja.setText(String.valueOf(currentItem.getPitanja().size()));
        } else if (gridLayout) {
            brojPitanja.setText("");
        }

        return convertView;
    }

}
