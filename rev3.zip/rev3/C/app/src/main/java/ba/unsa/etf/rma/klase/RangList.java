package ba.unsa.etf.rma.klase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RangList {
    public class Tuple implements Comparator<Tuple> {
        private int position;
        private String player;
        private double percentage;

        public Tuple() {

        }

        public Tuple(int position, String player, double percentage) {
            this.position = position;
            this.player = player;
            this.percentage = percentage;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }

        public String getPlayer() {
            return player;
        }

        public void setPlayer(String player) {
            this.player = player;
        }

        public double getPercentage() {
            return percentage;
        }

        public void setPercentage(double percentage) {
            this.percentage = percentage;
        }

        @Override
        public int compare(Tuple tuple, Tuple t1) {
            return Integer.compare(tuple.getPosition(), t1.getPosition());
        }
    }


    private Kviz quiz;
    private String databaseId;

    private ArrayList<Tuple> lista = new ArrayList<>();

    public RangList(Kviz quiz) {
        this.quiz = quiz;
    }

    public void registerGame(String player, double percentage) {
        Collections.sort(lista, new Tuple());
        //Log.d("tag","HERE");

        int newPosition = lista.size();
        for (int i = 0; i < lista.size(); i++) {
            if (percentage == lista.get(i).getPercentage()) {
                newPosition = lista.get(i).getPosition();
                break;
            }

            if (percentage > lista.get(i).getPercentage()) {
                newPosition = lista.get(i).getPosition();
                for (int j = i; j < lista.size(); j++) {
                    if (lista.get(j).getPosition() == newPosition) {
                        lista.get(j).setPosition(newPosition + 1);
                    } else {
                        lista.get(j).setPosition(lista.get(j).getPosition());
                    }
                }
                break;
            }
        }

        if (newPosition == 0) {
            newPosition++;
        }
        lista.add(new Tuple(newPosition, player, percentage));
        Collections.sort(lista, new Tuple());

        /*for(Tuple t : lista){
            Log.d("tag", t.getPlayer() + " " + t.getPosition() + " " + t.getPercentage());
        }*/
    }

    public Kviz getQuiz() {
        return quiz;
    }

    public ArrayList<Tuple> getList() {
        return lista;
    }

    public String getDatabaseId() {
        return databaseId;
    }

    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }


    public void add(int position, String player, double percentage) {
        lista.add(new Tuple(position, player, percentage));
        Collections.sort(lista, new Tuple());
    }
}
