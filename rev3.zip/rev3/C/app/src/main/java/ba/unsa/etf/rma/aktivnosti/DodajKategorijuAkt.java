package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddCategoryTask;
import ba.unsa.etf.rma.utilities.AsyncAddCategoryTaskResponse;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback, AsyncAddCategoryTaskResponse {

    private Icon[] selectedIcons;
    EditText iconId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kategoriju_akt);

        final EditText categoryName = findViewById(R.id.etNaziv);
        iconId = findViewById(R.id.etIkona);
        Button addIcon = findViewById(R.id.btnDodajIkonu);
        Button addCategory = findViewById(R.id.btnDodajKategoriju);

        final IconDialog iconDialog = new IconDialog();
        addIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        categoryName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                categoryName.setBackgroundColor(Color.TRANSPARENT);
            }
        });

        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validText(categoryName.getText().toString()) && validText(iconId.getText().toString())) {

                    Kategorija category = new Kategorija(categoryName.getText().toString(), iconId.getText().toString());

                    if (!uniqueCategory(category.getNaziv())) {
                        showAlertDialog("Ova kategorija već postoji!");
                        return;
                    }

                    addCategoryToDatabase(category);
                } else {
                    if (!validText(categoryName.getText().toString())) {
                        categoryName.setBackgroundColor(Color.RED);
                    }
                }
            }
        });

    }

    private void addCategoryToDatabase(Kategorija category) {
        new AddCategoryTask(DodajKategorijuAkt.this, this).execute(category);
    }

    private boolean validText(String text) {
        return !text.isEmpty();
    }

    private boolean uniqueCategory(String categoryName) {
        for (Kategorija k : Cache.getInstance(DodajKategorijuAkt.this).getCategories()) {
            if (k != null && k.getNaziv().equals(categoryName)) return false;
        }

        return true;
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        iconId.setText(Integer.toString(selectedIcons[0].getId()));
    }

    public void showAlertDialog(String message) {
        new AlertDialog.Builder(DodajKategorijuAkt.this).setMessage(message).
                setNeutralButton(android.R.string.ok, (dialogInterface, i) -> dialogInterface.cancel()).show();

    }

    @Override
    public void finishedAdd(String id) {
        Cache.getInstance(DodajKategorijuAkt.this).update();
        Intent intent = new Intent();
        intent.putExtra("databaseId", id);
        Log.d("kategorija", id);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}
