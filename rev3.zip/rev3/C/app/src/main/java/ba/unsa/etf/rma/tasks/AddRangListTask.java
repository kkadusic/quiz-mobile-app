package ba.unsa.etf.rma.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.RangList;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.AsyncAddRangListTaskResponse;

public class AddRangListTask extends AsyncTask<RangList, Void, Void> {

    private AsyncAddRangListTaskResponse delegate;
    private WeakReference<Context> context;

    public AddRangListTask(Context context, AsyncAddRangListTaskResponse delegate) {
        this.context = new WeakReference<>(context);
        this.delegate = delegate;
    }

    @Override
    protected Void doInBackground(RangList... rangLists) {
        String kolekcija = "Rangliste";

        InputStream is = context.get().getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials;
        try {
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala3-1998/databases/(default)/documents/" + kolekcija + "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/jason");
            conn.setRequestProperty("Accept", "application/jason");

            String document = createDocument(rangLists[0]);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String createDocument(RangList rangList) {
        String document = "";


        document += "{\"fields\": {\"nazivKviza\": {\"stringValue\": \"" + rangList.getQuiz().getNaziv() + "\"},"
                + "\"lista\": {\"mapValue\": { \"fields\":{";

        ArrayList<RangList.Tuple> list = rangList.getList();
        for (int i = 0; i < list.size(); i++) {
            int position = list.get(i).getPosition();
            document += "\"" + position + "\": {\"mapValue\": {\"fields\": {";
            while (i < list.size() && list.get(i).getPosition() == position) {
                document += "\"" + list.get(i).getPlayer() + "\": {\"stringValue\": \"" + list.get(i).getPercentage() + "\"},";
                i++;
            }
            document = document.substring(0, document.length() - 1); //brisanje zadnjeg zareza
            i--;
            document += "}}},";
        }
        document = document.substring(0, document.length() - 1); //brisanje zadnjeg zareza
        document += "}}}";
        document += "}}";

        return document;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        delegate.finishedAdd();
    }
}
