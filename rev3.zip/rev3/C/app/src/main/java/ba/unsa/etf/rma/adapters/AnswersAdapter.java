package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.projekat.R;

public class AnswersAdapter extends ArrayAdapter<String> {
    private int correctPositon;
    private int choosenAnswerPosition;
    private boolean playing = false;
    private ArrayList<String> answers;
    private ListView listView;

    public AnswersAdapter(@NonNull Context context, ArrayList<String> objects, ListView listView) {
        super(context, 0, objects);
        answers = objects;
        setCorrectPositon(-1);
        this.listView = listView;
        setListViewHeightBasedOnChildren(listView);
    }

    public AnswersAdapter(@NonNull Context context, ArrayList<String> objects, boolean playing, ListView listView) {
        super(context, 0, objects);
        setCorrectPositon(-1);
        setChoosenAnswerPosition(-1);
        this.playing = playing;
        answers = objects;
        this.listView = listView;
        setListViewHeightBasedOnChildren(listView);
    }

    public void setObjects(ArrayList<String> objects){
        answers.clear();
        for(String s : objects){
            answers.add(s);
            setListViewHeightBasedOnChildren(listView);
        }
        setChoosenAnswerPosition(-1);
        notifyDataSetChanged();
    }

    @Override
    public void add(@Nullable String object) {
        super.add(object);
        setListViewHeightBasedOnChildren(listView);
    }

    public void setCorrectPositon(int correctPositon) {
        this.correctPositon = correctPositon;
        notifyDataSetChanged();
    }

    public int getCorrectPositon() {
        return correctPositon;
    }

    public int getChoosenAnswerPosition() {
        return choosenAnswerPosition;
    }

    public void setChoosenAnswerPosition(int choosenAnswerPosition) {
        this.choosenAnswerPosition = choosenAnswerPosition;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);

    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.answer, parent, false);
        }

        TextView answer = convertView.findViewById(R.id.answer);
        RelativeLayout rl = convertView.findViewById(R.id.relativeLayout);

        String currentAnswer = getItem(position);
        if(currentAnswer != null){
            answer.setText(currentAnswer);
            rl.setBackgroundColor(Color.TRANSPARENT);
            if(!playing) {
                if (position == correctPositon){
                    rl.setBackgroundColor(getContext().getResources().getColor(R.color.zelena));
                }
            }
            else{ //needs fixing
                if(position == correctPositon && choosenAnswerPosition != -1){
                    rl.setBackgroundColor(getContext().getResources().getColor(R.color.zelena));
                }else if(position != correctPositon && choosenAnswerPosition != -1 && position == choosenAnswerPosition){
                    rl.setBackgroundColor(getContext().getResources().getColor(R.color.crvena));
                }
            }
        }

        return convertView;
    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        int totalHeight = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < getCount(); i++) {
            View listItem = getView(i, null, listView);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    public void dynamicallyResize() {
        setListViewHeightBasedOnChildren(listView);
    }

    public boolean contains(String s) {
        return answers.contains(s);
    }
}
