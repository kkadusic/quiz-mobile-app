package ba.unsa.etf.rma.utilities;

public interface AsyncEditTaskResponse {
    void finishedEdit();
}
