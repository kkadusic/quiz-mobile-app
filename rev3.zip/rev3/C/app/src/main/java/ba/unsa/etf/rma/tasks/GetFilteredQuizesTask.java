package ba.unsa.etf.rma.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.enums.Type;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.AsyncGetTaskResponse;

public class GetFilteredQuizesTask extends AsyncTask<Kategorija, Void, String> {

    private AsyncGetTaskResponse delegate;
    private WeakReference<Context> context;

    public GetFilteredQuizesTask(Context context, AsyncGetTaskResponse delegate) {
        this.delegate = delegate;
        this.context = new WeakReference<>(context);
    }

    @Override
    protected String doInBackground(Kategorija... categories) {
        String query;
        if (categories[0].equals(new Kategorija("Svi", "0"))) {
            query = getAllQuery();
        } else {
            String constraint = categories[0].getDatabaseId();
            query = getFilteredQuery(constraint);
        }
        InputStream is = context.get().getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials = null;
        try {
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala3-1998/databases/(default)/documents:runQuery?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = query.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                return response.toString();
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private String getAllQuery() {
        String query = "";
        query += "{\"structuredQuery\": {\"from\": [{\"collectionId\": \"Kvizovi\"}]}}";
        return query;
    }

    private String getFilteredQuery(String constraint) {
        String query = "";
        query += "{\n" +
                "    \"structuredQuery\": {\n" +
                "        \"where\" : {\n" +
                "            \"fieldFilter\" : { \n" +
                "                \"field\": {\"fieldPath\": \"idKategorije\"}, \n" +
                "                \"op\":\"EQUAL\", \n" +
                "                \"value\": {\"stringValue\": \"" + constraint + "\"}\n" +
                "            }\n" +
                "        },\n" +
                "        \"from\": [{\"collectionId\": \"Kvizovi\"}]\n" +
                "    }\n" +
                "}";

        return query;
    }


    @Override
    protected void onPostExecute(String response) {
        super.onPostExecute(response);
        delegate.processResults(response, Type.Quiz);
    }
}
