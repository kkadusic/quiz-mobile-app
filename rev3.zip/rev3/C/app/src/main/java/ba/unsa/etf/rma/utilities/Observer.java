package ba.unsa.etf.rma.utilities;

public interface Observer {
    void update();
}
