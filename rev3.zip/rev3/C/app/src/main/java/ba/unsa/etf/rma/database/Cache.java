package ba.unsa.etf.rma.database;

import android.content.Context;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import ba.unsa.etf.rma.enums.Type;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangList;
import ba.unsa.etf.rma.tasks.GetFilteredQuizesTask;
import ba.unsa.etf.rma.tasks.GetObjectsTask;
import ba.unsa.etf.rma.utilities.AsyncGetTaskResponse;
import ba.unsa.etf.rma.utilities.JSONListParser;
import ba.unsa.etf.rma.utilities.Observer;

public class Cache implements AsyncGetTaskResponse {

    private static Cache cache = null;
    private static ArrayList<Kviz> quizes;
    private static ArrayList<Kategorija> categories;
    private static ArrayList<Pitanje> questions;
    private static WeakReference<Context> context;
    private static Observer observerActivity = null;
    private static Kategorija constraint;
    private static ArrayList<RangList> rangLists;

    private Cache() {
        quizes = new ArrayList<>();
        categories = new ArrayList<>();
        questions = new ArrayList<>();
        rangLists = new ArrayList<>();
        readFromDatabase();
    }

    public static Cache getInstance(Context context) {
        Cache.context = new WeakReference<>(context);
        Cache.constraint = new Kategorija("Svi", "0");
        if (cache == null) {
            cache = new Cache();
        }
        return cache;
    }

    public static Cache getInstance(Context context, Observer observer) {
        Cache.context = new WeakReference<>(context);
        Cache.observerActivity = observer;
        Cache.constraint = new Kategorija("Svi", "0");
        if (cache == null) {
            cache = new Cache();
        }
        return cache;
    }

    public static Cache getInstance(Context context, Observer observer, Kategorija constraint) {
        Cache.context = new WeakReference<>(context);
        Cache.observerActivity = observer;
        Cache.constraint = constraint;
        if (cache == null) {
            cache = new Cache();
        }
        return cache;
    }

    private void readFromDatabase() {
        GetObjectsTask task = new GetObjectsTask(context.get(), this, Type.Category);
        task.execute();
    }

    @Override
    public void processResults(String response, Type type) {
        if (type.equals(Type.Category)) {
            categories = new JSONListParser(context.get()).parseCategories(response);
            categories.add(null);
            GetObjectsTask task = new GetObjectsTask(context.get(), this, Type.Question);
            task.execute();
        } else if (type.equals(Type.Question)) {
            questions = new JSONListParser(context.get()).parseQuestions(response);
            GetFilteredQuizesTask task = new GetFilteredQuizesTask(context.get(), this);
            task.execute(constraint);
        } else if (type.equals(Type.Quiz)) {
            quizes = new JSONListParser(context.get()).parseQuizes(response);
            quizes.add(null);
            GetObjectsTask task = new GetObjectsTask(context.get(), this, Type.Ranglist);
            task.execute();
        } else {
            rangLists = new JSONListParser(context.get()).parserRangLists(response);
        }

        if (observerActivity != null) {
            observerActivity.update();
        }
    }

    public Pitanje getQuestionById(String questionId) {
        for (Pitanje question : questions) {
            if (question.getDatabaseId().equals(questionId)) return question;
        }

        return null;
    }

    public Kategorija getCategoryById(String categoryId) {
        for (Kategorija category : categories) {
            if (category.getDatabaseId().equals(categoryId)) return category;
        }

        return null;
    }

    public void update() {
        readFromDatabase();
    }

    public ArrayList<Kategorija> getCategories() {
        return categories;
    }

    public ArrayList<Pitanje> getQuestions() {
        return questions;
    }

    public ArrayList<Kviz> getQuizes() {
        return quizes;
    }

    public RangList getRangListForQuiz(Kviz quiz) {
        for (RangList rangList : rangLists) {
            if (quiz.getNaziv().equals(rangList.getQuiz().getNaziv())) return rangList;
        }

        return null;

    }

    public Kviz getQuizByName(String name) {
        for (Kviz quiz : quizes) {
            if (quiz != null && name.equals(quiz.getNaziv())) return quiz;
        }

        return null;
    }
}
