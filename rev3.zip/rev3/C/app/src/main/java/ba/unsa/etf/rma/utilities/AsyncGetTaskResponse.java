package ba.unsa.etf.rma.utilities;

import ba.unsa.etf.rma.enums.Type;

public interface AsyncGetTaskResponse {
    void processResults(String response, Type type);
}
