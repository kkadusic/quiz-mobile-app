package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.EditText;
import android.widget.LinearLayout;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangList;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddRangListTask;
import ba.unsa.etf.rma.tasks.EditRangListTask;
import ba.unsa.etf.rma.utilities.AsyncAddRangListTaskResponse;
import ba.unsa.etf.rma.utilities.Observer;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.InformationFragmentListener, PitanjeFrag.QuestionFragmentListener,
        AsyncAddRangListTaskResponse, Observer {

    private InformacijeFrag informationFragment;
    private PitanjeFrag questionFragment;
    private RangLista rangListFragment;
    private Kviz quiz;
    private boolean firstTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igraj_kviz_akt);

        quiz = getIntent().getParcelableExtra("kviz");

        informationFragment = new InformacijeFrag();
        questionFragment = new PitanjeFrag();
        rangListFragment = new RangLista();

        Bundle args1 = new Bundle();
        args1.putParcelable("quiz", quiz);
        informationFragment.setArguments(args1);
        rangListFragment.setArguments(args1);

        Bundle args2 = new Bundle();
        args2.putParcelableArrayList("questions", quiz.getPitanja());
        questionFragment.setArguments(args2);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.informacijePlace, informationFragment)
                .replace(R.id.pitanjePlace, questionFragment)
                .commit();
    }

    @Override
    public void finishPlaying() {
        questionFragment.endQuiz();
        setResult(Activity.RESULT_OK, getIntent());
        finish();
    }

    @Override
    public void processAnswer(boolean correct) {
        informationFragment.updateInformation(correct);
    }

    @Override
    public void updateRemaining() {
        informationFragment.updateRemaining();
    }

    @Override
    public void updateRangList() {
        Cache.getInstance(IgrajKvizAkt.this, this).update();
    }

    private void showDialog() {
        final String[] player = new String[1];
        AlertDialog.Builder alert = new AlertDialog.Builder(IgrajKvizAkt.this);
        alert.setMessage("Unesite vaše ime");
        final EditText input = new EditText(IgrajKvizAkt.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alert.setView(input);
        alert.setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                player[0] = input.getText().toString();
                getSupportFragmentManager().beginTransaction().replace(R.id.pitanjePlace, rangListFragment).commit();
                addOrUpdateRangList(player[0]);
                dialogInterface.cancel();
            }
        });
        alert.show();
    }

    private void addOrUpdateRangList(String s) {
        RangList rangList = Cache.getInstance(IgrajKvizAkt.this, this).getRangListForQuiz(quiz);
        if (rangList == null) {
            Log.d("tag","PRAVIM LISTU");
            rangList = new RangList(quiz);
            rangList.registerGame(s, informationFragment.getPercentageOfCorrect());
            new AddRangListTask(IgrajKvizAkt.this, this).execute(rangList);
        } else {
            Log.d("tag", "AZURIRAM LISTU");
            rangList.registerGame(s, informationFragment.getPercentageOfCorrect());
            new EditRangListTask(IgrajKvizAkt.this, this).execute(rangList);
        }
    }

    @Override
    public void finishedAdd() {
        Cache.getInstance(IgrajKvizAkt.this, this).update();
    }

    @Override
    public void update() {
        if (firstTime) {
            showDialog();
            firstTime = false;
        } else {
            rangListFragment.update();
        }
    }
}
