package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangList;
import ba.unsa.etf.rma.projekat.R;

public class RangListAdapter extends ArrayAdapter<RangList.Tuple> {

    private RangList rangList;
    private Kviz quiz;

    public RangListAdapter(@NonNull Context context, Kviz quiz) {
        super(context, 0);
        this.rangList = Cache.getInstance(context).getRangListForQuiz(quiz);
        this.quiz = quiz;
    }

    @Nullable
    @Override
    public RangList.Tuple getItem(int position) {
        return getObjects().get(position);
    }

    @Override
    public int getCount() {
        return getObjects().size();
    }

    @Override
    public int getPosition(@Nullable RangList.Tuple item) {
        return getObjects().indexOf(item);
    }

    public ArrayList<RangList.Tuple> getObjects() {
        if( Cache.getInstance(getContext()).getRangListForQuiz(quiz) == null) return new ArrayList<>();
        return Cache.getInstance(getContext()).getRangListForQuiz(quiz).getList();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.rang_list_element, parent, false);
        }

        TextView pos = convertView.findViewById(R.id.position);
        TextView player = convertView.findViewById(R.id.playerName);
        TextView percentage = convertView.findViewById(R.id.percentage);

        RangList.Tuple current = getItem(position);

        pos.setText(String.valueOf(current.getPosition()));
        player.setText(current.getPlayer());
        percentage.setText(String.valueOf(current.getPercentage()) + "%");

        return convertView;
    }
}
