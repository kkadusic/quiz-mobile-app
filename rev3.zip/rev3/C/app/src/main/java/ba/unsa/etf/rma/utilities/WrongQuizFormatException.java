package ba.unsa.etf.rma.utilities;

public class WrongQuizFormatException extends Throwable {
    private String message;

    public WrongQuizFormatException(String s) {
        this.message = s;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
