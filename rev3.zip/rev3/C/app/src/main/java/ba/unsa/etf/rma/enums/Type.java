package ba.unsa.etf.rma.enums;

public enum Type {
    Quiz, Question, Category, Ranglist
}
