package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

import ba.unsa.etf.rma.adapters.AnswersAdapter;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;

public class PitanjeFrag extends Fragment {
    private TextView question;
    private ListView answers;
    private Context context;

    private AnswersAdapter answersAdapter;

    private QuestionFragmentListener questionFragmentListener;

    private ArrayList<Pitanje> questions;
    private int randomIndex = -1;


    public interface QuestionFragmentListener {
        void processAnswer(boolean correct);

        void updateRemaining();

        void updateRangList();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pitanje_frag, container, false);

        question = view.findViewById(R.id.tekstPitanja);
        answers = view.findViewById(R.id.odgovoriPitanja);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        if (context instanceof QuestionFragmentListener) {
            questionFragmentListener = (QuestionFragmentListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        questionFragmentListener = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        answersAdapter = new AnswersAdapter(context, new ArrayList<>(), true, answers);
        answers.setAdapter(answersAdapter);
        answers.setOnItemClickListener((adapterView, view, i, l) -> {
            answersAdapter.setChoosenAnswerPosition(i);
            questionFragmentListener.processAnswer(i == answersAdapter.getCorrectPositon());
            answers.setEnabled(false);

            new Handler().postDelayed(() -> {
                answers.setEnabled(true);
                displayQuestion();
            }, 2000);
        });

        Bundle args = getArguments();
        questions = args.getParcelableArrayList("questions");

        displayQuestion();
    }

    public void displayQuestion() {
        questionFragmentListener.updateRemaining();

        if (randomIndex != -1) {
            questions.remove(randomIndex);
        }
        if (questions.size() > 0) {
            randomIndex = chooseRandomIndex();
            Pitanje p = questions.get(randomIndex);
            this.question.setText(p.getNaziv());
            answersAdapter.setObjects(p.getOdgovori());
            answersAdapter.setCorrectPositon(p.getOdgovori().indexOf(p.getTacan()));
            answersAdapter.notifyDataSetChanged();
        } else {
            endQuiz();
            questionFragmentListener.updateRangList();
        }
    }

    public void endQuiz() {
        question.setText(R.string.zavrsen_kviz);
        answersAdapter.setObjects(new ArrayList<>());
    }

    public int chooseRandomIndex() {
        Random random = new Random();
        return random.nextInt(questions.size());
    }

}
