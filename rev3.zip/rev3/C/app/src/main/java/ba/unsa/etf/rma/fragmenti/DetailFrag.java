package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import ba.unsa.etf.rma.adapters.QuizesAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.Observer;

public class DetailFrag extends Fragment implements Observer {

    private DetailFragmentListener mListener;
    private GridView quizes;
    private QuizesAdapter gridViewAdapter;

    public DetailFrag() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        gridViewAdapter = new QuizesAdapter(getContext(), this, true);
        quizes.setAdapter(gridViewAdapter);
        gridViewAdapter.notifyDataSetChanged();

        quizes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Kviz quiz = (Kviz) adapterView.getItemAtPosition(i);
                mListener.onQuizSelected(quiz);
            }
        });


        quizes.setLongClickable(true);
        quizes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Kviz quiz = (Kviz) adapterView.getItemAtPosition(i);

                mListener.onQuizLongSelected(quiz);
                return true;
            }
        });

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detail_frag, container, false);

        quizes = view.findViewById(R.id.gridKvizovi);

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof DetailFragmentListener) {
            mListener = (DetailFragmentListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement ListFragmentListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void showQuizes(Kategorija constraint) {
        gridViewAdapter.updateConstraint(constraint);
    }

    public void processResults(boolean add, Kviz k) {
        gridViewAdapter.updateConstraint(new Kategorija("Svi", "0"));
        gridViewAdapter.notifyDataSetChanged();
    }

    @Override
    public void update() {
        gridViewAdapter.notifyDataSetChanged();
    }

    public interface DetailFragmentListener {
        void onQuizSelected(Kviz quiz);

        void onQuizLongSelected(Kviz quiz);
    }
}
