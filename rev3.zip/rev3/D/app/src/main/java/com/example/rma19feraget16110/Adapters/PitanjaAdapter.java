package com.example.rma19feraget16110.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class PitanjaAdapter extends ArrayAdapter<String> {
    private ArrayList<Pitanje> pitanja;
    private Context context;
    public  PitanjaAdapter(Context context, int resource, ArrayList<Pitanje> pitanja){
        super(context,resource);
        this.context=context;
        this.pitanja=pitanja;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder=new ViewHolder();
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.pitanja_kviz,parent,false);
            holder.slika=convertView.findViewById(R.id.iSlika);
            holder.nazivPitanja =convertView.findViewById(R.id.tPitanjaKviza);
            convertView.setTag(holder);
        } else
            holder=(ViewHolder)convertView.getTag();
        if(pitanja.get(position).getNaziv().toLowerCase().equals("dodaj pitanje"))
            Picasso.get().load(R.drawable.plus).into(holder.slika);
        else
            Picasso.get().load(R.drawable.circle).into(holder.slika);
            holder.nazivPitanja.setText(pitanja.get(position).getNaziv());
            return convertView;
    }

    static class ViewHolder{
        ImageView slika;
        TextView nazivPitanja;
    }

    @Override
    public int getCount() {
        return pitanja.size();
    }
}
