package com.example.rma19feraget16110.Validation;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.text.TextUtils;
import android.widget.EditText;

import java.util.ResourceBundle;

public class ValidatorClass {
    public boolean validateField(EditText editText){
        String unos=editText.getText().toString();
        if(TextUtils.isEmpty(unos)){
            editText.setError("The item cannot be empty");
            return true;
        }
        return false;
    }

}
