package com.example.rma19feraget16110.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OdgovoriAdapter extends ArrayAdapter<String> {
    private ArrayList<String> moguciOdgvori;
    private Context context;
    public  OdgovoriAdapter(Context context, int resource, ArrayList<String> moguciOdgovori){
        super(context,resource);
        this.context=context;
        this.moguciOdgvori=moguciOdgovori;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder=new ViewHolder();
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.odgovori,parent,false);
            holder.slika=convertView.findViewById(R.id.iSlikaOdgovor);
            holder.text =convertView.findViewById(R.id.tOdgovorPitanja);
            convertView.setTag(holder);
        } else
            holder=(ViewHolder)convertView.getTag();
            Picasso.get().load(R.drawable.circle).into(holder.slika);
        holder.text.setText(moguciOdgvori.get(position));
        return convertView;
    }

    static class ViewHolder{
        ImageView slika;
        TextView text;
    }

    @Override
    public int getCount() {
        return moguciOdgvori.size();
    }
}
