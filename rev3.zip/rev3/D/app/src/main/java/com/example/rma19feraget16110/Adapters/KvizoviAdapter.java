package com.example.rma19feraget16110.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class KvizoviAdapter extends BaseAdapter {
    private ArrayList<Kviz> filteredData=new ArrayList<>();
    private ArrayList<Kviz> kvizovi;
    private Context context;
    public  KvizoviAdapter(Context context, int resource, ArrayList<Kviz> kvizovi){
        this.context=context;
        this.kvizovi=kvizovi;
    }
    @Override
    public int getCount() {
        return kvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return kvizovi.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //filteredData.add(new Kviz("Dodaj Kviz"));
        ViewHolder holder=new ViewHolder();
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.kvizovi,parent,false);
            holder.slika=convertView.findViewById(R.id.iSlikaKviza);
            holder.nazivKviza =convertView.findViewById(R.id.tNazivKviza);
            convertView.setTag(holder);
        } else
            holder=(ViewHolder)convertView.getTag();
        if(kvizovi.get(position).getNaziv().toLowerCase().equals("dodaj kviz"))
            Picasso.get().load(R.drawable.plus).into(holder.slika);
        else
            Picasso.get().load(R.drawable.circle).into(holder.slika);
        holder.nazivKviza.setText(kvizovi.get(position).getNaziv());
        return convertView;
    }

    /*@Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                if(constraint == null || constraint.length() == 0){
                    results.values = kvizovi;
                    results.count = kvizovi.size();
                } else {
                    ArrayList<Kviz> filterResultData = new ArrayList<>();
                    for(Kviz data : kvizovi){
                        if(data.getKategorija().getNaziv().toLowerCase().equals(constraint.toString().toLowerCase())
                                || data.getNaziv().equals("Dodaj Kviz"))
                            filterResultData.add(data);
                    }
                    results.values = filterResultData;
                    results.count = filterResultData.size();
                }
                return  results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredData = (ArrayList<Kviz>) results.values;
                notifyDataSetChanged();
            }
        };
    }*/

    static class ViewHolder{
        ImageView slika;
        TextView nazivKviza;
    }
}
