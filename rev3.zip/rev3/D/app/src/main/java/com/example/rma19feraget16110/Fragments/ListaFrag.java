package com.example.rma19feraget16110.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.R;

import java.util.ArrayList;

public class ListaFrag extends Fragment  {
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Kviz> kvizovi = new ArrayList<>();

    private SendCategory sc;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View iv = inflater.inflate(R.layout.lista_frag,container,false);
        return iv;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof SendCategory){
            sc = (SendCategory) context;
        } else {
            throw new RuntimeException(context.toString()
                    + "must implemet listener!");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        sc = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments() != null && getArguments().containsKey("kategorije") && getArguments().containsKey("kvizovi")){
            kategorije = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");
            kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("kvizovi");
            ListView listaKat = getView().findViewById(R.id.listaKategorija);
            ArrayAdapter<Kategorija> listAdapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,kategorije);
            listaKat.setAdapter(listAdapter);
            listaKat.setOnItemClickListener((parent, view, position, id) -> {
                Kategorija kat = kategorije.get(position);
                sc.sendCategory(kat,position);
                //findKvizFromCategory(kat);
                //Bundle detailArgumenti = new Bundle();
                //detailArgumenti.putSerializable("sortedQuiz",filteredQuizes);
                FragmentManager fm=getActivity().getSupportFragmentManager();
                DetailFrag detailFrag = new DetailFrag();
                //detailFrag.setArguments(detailArgumenti);
                fm.beginTransaction().detach(detailFrag).replace(R.id.detailPlace,detailFrag);
            });
        }
    }

    public interface SendCategory{
        void sendCategory(Kategorija kategorija,Integer position);
    }
}
