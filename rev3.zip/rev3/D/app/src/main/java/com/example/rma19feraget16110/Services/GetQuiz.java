package com.example.rma19feraget16110.Services;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.rma19feraget16110.R;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class GetQuiz extends AsyncTask<String,Integer, JSONObject> {
    private Context mContext;
    String token;
    String kolekcija,idKategorije;
    JSONObject jo;
    private ReturnQuizes pozivatelj;


    @Override
    protected JSONObject doInBackground(String... strings) {
        kolekcija = strings[0];
        try {
            token = getToken();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("token",token);


        String getQuizQuery = "{\n" +
                "\"structuredQuery\": {\n" +
                "\"where\" : {\n" +
                "\"fieldFilter\": { \n" +
                "\"field\": {\"fieldPath\": \"idKategorije\"}, \n" +
                "\"op\":\"EQUAL\", \n" +
                "\"value\": {\"stringValue\": \"" + idKategorije + "\"}\n" +
                "}\n" +
                "},\n" +
                "\"select\": { \"fields\": [ {\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, {\"fieldPath\": \"pitanja\"}] },\n" +
                "\"from\": [{\"collectionId\": \"" + kolekcija + "\"}],\n" +
                "\"limit\": 100 \n" +
                "}\n"+
                "}";

        try {
            String url = "https://firestore.googleapis.com/v1/projects/spirala3-67197/databases/(default)/documents:runQuery?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(token,"UTF-8"));
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlObj.openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            try (OutputStream os = httpURLConnection.getOutputStream()) {
                byte[] input = getQuizQuery.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            int code = httpURLConnection.getResponseCode();
            InputStream odgovor = httpURLConnection.getInputStream();
            String rezultat = convertStreamToString(odgovor);
            rezultat = "{\"documents\":" + rezultat + "}";
            jo = new JSONObject(rezultat);
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))){
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = br.readLine()) != null){
                    response.append(responseLine.trim());
                }
                Log.d("ODGOVOR",response.toString());
                Log.d("CODE",String.valueOf(code));
            }



        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getToken() throws IOException {
        InputStream is = mContext.getApplicationContext().getResources().openRawResource(R.raw.secret);
        GoogleCredential credential = GoogleCredential.fromStream(is).
                createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credential.refreshToken();
        return credential.getAccessToken();
    }

    public GetQuiz(Context context,String idKategorije,ReturnQuizes p){
        mContext = context;
        this.idKategorije = idKategorije;
        pozivatelj = p;
    }

    private String convertStreamToString(InputStream in){
        BufferedReader reader=new BufferedReader(new InputStreamReader(in));
        StringBuilder sb=new StringBuilder();
        String line=null;
        try{
            while((line=reader.readLine())!=null){
                sb.append(line+"\n");
            }
        } catch (IOException e){

        }finally {
            try {
                in.close();
            }  catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public interface ReturnQuizes{
        void returnQuizes(JSONObject object) throws JSONException;
    }

    @Override
    protected void onPostExecute(JSONObject jsonObject) {
        super.onPostExecute(jsonObject);
        try {
            pozivatelj.returnQuizes(jo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
