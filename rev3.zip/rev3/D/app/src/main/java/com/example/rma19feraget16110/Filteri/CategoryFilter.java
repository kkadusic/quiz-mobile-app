package com.example.rma19feraget16110.Filteri;

import android.os.Build;
import android.support.annotation.RequiresApi;

import com.example.rma19feraget16110.Model.Kategorija;

import java.util.function.Predicate;
import java.util.regex.Pattern;

@RequiresApi(api = Build.VERSION_CODES.N)
public final class CategoryFilter implements Predicate<Kategorija> {
    private final Pattern pattern;

    public CategoryFilter(final String regex){
        pattern=Pattern.compile(regex);
    }

    @Override
    public boolean test(Kategorija kategorija) {
        return pattern.matcher(kategorija.getNaziv()).find();
    }
}
