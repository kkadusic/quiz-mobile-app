package com.example.rma19feraget16110.Services;

import com.example.rma19feraget16110.Model.Pitanje;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public interface IExtractCategories {
    ArrayList<Pitanje> extractCategories(JSONObject categories) throws JSONException;
}
