package com.example.rma19feraget16110.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.ResourceBundle;

public class MogucaPitanjaAdapter extends ArrayAdapter<Pitanje> {
    private ArrayList<Pitanje> mogucaPitanja;
    private Context context;
    public MogucaPitanjaAdapter(Context context, int resource, ArrayList<Pitanje> mogucaPitanja){
        super(context,resource);
        this.context=context;
        this.mogucaPitanja=mogucaPitanja;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder=new ViewHolder();
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.moguca_pitanja,parent,false);
            holder.text =convertView.findViewById(R.id.etmogucePitanje);
            convertView.setTag(holder);
        } else
            holder=(ViewHolder)convertView.getTag();
        holder.text.setText(mogucaPitanja.get(position).getNaziv());
        return convertView;
    }
    static class ViewHolder{
        TextView text;
    }

    @Override
    public int getCount() {
        return mogucaPitanja.size();
    }
}
