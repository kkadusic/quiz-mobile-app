package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KategorijaAdapter;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizoviAkt extends AppCompatActivity {
    private Spinner  spPostojeceKategorije;
    private ListView lvKvizovi;

    private KvizAdapter       kvizAdapter;
    private KategorijaAdapter kategorijaAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_kvizovi_akt);

        spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
        lvKvizovi             = (ListView)findViewById(R.id.lvKvizovi);


        kategorijaAdapter = new KategorijaAdapter(this);
        spPostojeceKategorije.setAdapter(kategorijaAdapter);
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                kvizAdapter.setKategorija(kategorijaAdapter.getItem(i).getId());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        kvizAdapter = new KvizAdapter(this);
        lvKvizovi.setAdapter(kvizAdapter);
        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                if (!kvizAdapter.isSpecial(position)) {
                    Kviz kviz = kvizAdapter.getItem(position);

                    intent.putExtra(DodajKvizAkt.KVIZ_IS_UPDATE, true);
                    intent.putExtra(DodajKvizAkt.KVIZ_NAZIV, kviz.getNaziv());
                }

                startActivity(intent);
            }
        });
    }
}
