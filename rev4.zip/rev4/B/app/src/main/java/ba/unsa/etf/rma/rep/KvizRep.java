package ba.unsa.etf.rma.rep;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kviz;

public class KvizRep {
    private static ArrayList<Kviz> Kvizovi;

    //region Singleton
    private KvizRep() {
        Kvizovi = new ArrayList<>();
    }

    private static KvizRep _This;
    public  static KvizRep Instance() {
        if (_This == null)
            _This = new KvizRep();

        return _This;
    }
    //endregion


    public ArrayList<Kviz> getAll() {
        return Kvizovi;
    }

    public ArrayList<Kviz> getByKategorija(String id) {
        ArrayList<Kviz> result = new ArrayList<>();

        for (Kviz k : Kvizovi)
            if (k.getKategorija().getId().equals(id))
                result.add(k);

        return result;
    }

    public Kviz get(String naziv) {
        for (Kviz k : Kvizovi)
            if (k.getNaziv().equals(naziv))
                return k;

        return null;
    }

    public void add(Kviz k) {
        Kvizovi.add(k);
    }

    public boolean nazivExists(String naziv) {
        for (Kviz k : Kvizovi)
            if (k.getNaziv().equals(naziv))
                return true;

        return false;
    }
}
