package ba.unsa.etf.rma.rep;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;

public class KategorijaRep {
    private static ArrayList<Kategorija> Kategorije;

    //region Singleton
    private KategorijaRep() {
        Kategorije = new ArrayList<>();
    }

    private static KategorijaRep _This;
    public  static KategorijaRep Instance() {
        if (_This == null)
            _This = new KategorijaRep();

        return _This;
    }
    //endregion


    public ArrayList<Kategorija> getAll() {
        return Kategorije;
    }

    public Kategorija get(String id) {
        for (Kategorija k : Kategorije)
            if (k.getId().equals(id))
                return k;

        return null;
    }

    public void add(Kategorija k) {
        Kategorije.add(k);
    }

    public int count() {
        return Kategorije.size();
    }

    public boolean idExist(String id) {
        for (Kategorija k : Kategorije)
            if (k.getId().equals(id))
                return true;

        return false;
    }

    public boolean nazivExist(String naziv) {
        for (Kategorija k : Kategorije)
            if (k.getNaziv().equals(naziv))
                return true;

        return false;
    }
}
