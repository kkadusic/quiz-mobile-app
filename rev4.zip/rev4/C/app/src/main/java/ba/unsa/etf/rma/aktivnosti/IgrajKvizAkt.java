package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.Calendar;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;

import static android.content.DialogInterface.BUTTON_NEUTRAL;
import static ba.unsa.etf.rma.klase.ShareIgraj.igraj_kviz;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.OnFragmentInfInteractionListener,PitanjeFrag.OnFragmentInteractionListener{
    private InformacijeFrag im_fragment = new InformacijeFrag();
    private PitanjeFrag pm_fragment = new PitanjeFrag();
    private Cursor cursor;
    public static  int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION =1;


    public class AlertReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, final Intent intent) {
            AlertDialog alert= new AlertDialog.Builder(context).create();
            alert.setTitle("Alarm");
            alert.setMessage("ALARM JE AKTIVIRAN!");
            alert.setButton(BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            finish();

                        }
                    });
            alert.show();
        }

    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_igrajkviz);
        Configuration config = getResources().getConfiguration();
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();

            fragmentTransaction.replace(R.id.informacije_place, im_fragment);
            fragmentTransaction.commit();
        FragmentTransaction fragmentTransaction2 =
                fragmentManager.beginTransaction();

            fragmentTransaction2.replace(R.id.pitanje_place, pm_fragment);
            fragmentTransaction2.commit();
        boolean imaEvent=false;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_CALENDAR},MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
        else if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED){

        cursor= getContentResolver().query(CalendarContract.Events.CONTENT_URI,null,null,null,null);

        Calendar kalendar = Calendar.getInstance();
            double v = igraj_kviz.getPitanja().size()/2.0;
            int vrijeme = (int) Math.ceil(v);
            long razlikaPrvog=-1;


        while(cursor.moveToNext()) {


            if (cursor != null) {
                String title= cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE));
                String datum= cursor.getString(cursor.getColumnIndex(CalendarContract.Events.RDATE));
                String eventVrijeme=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTSTART));
                long vrijemeEventa= Long.parseLong(eventVrijeme);
                long trenutnoVrijeme=kalendar.getTimeInMillis();
                long razlika;
                razlika=vrijemeEventa-trenutnoVrijeme;
                if(razlika>0 && razlika<=vrijeme*60*1000){
                    if(razlika<razlikaPrvog || razlikaPrvog<0) razlikaPrvog=razlika;
                    imaEvent=true;
                }




            }else{

            }
        }

        if(imaEvent){
            AlertDialog alert= new AlertDialog.Builder(this).create();
            alert.setTitle("Event");
            alert.setMessage("Imate događaj u kalendaru za "+razlikaPrvog/60000+" minuta!");
            alert.setButton(BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            finish();

                        }
                    });
            alert.show();
        }
        else {


            kalendar.add(Calendar.SECOND, vrijeme * 60);
            AlertReceiver alertReceiver = new AlertReceiver();
            this.registerReceiver(alertReceiver, new IntentFilter("alarm"));
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent("alarm"), 0);
            AlarmManager am = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
            am.set(AlarmManager.RTC_WAKEUP, kalendar.getTimeInMillis(), pi);
        }
    }
    }

    @Override
    public void onFragmentInteraction(Kviz kviz) {
       im_fragment.changeInf();
    }

    @Override
    public void onFragmentInfInteraction() {
        Intent intent = new Intent();
        setResult(4,intent);
        finish();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1 : {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
