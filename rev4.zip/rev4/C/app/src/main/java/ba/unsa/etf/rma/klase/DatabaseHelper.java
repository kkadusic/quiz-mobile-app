package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String name="kvizovi";
    private static final String naziv="naziv";
    public DatabaseHelper(Context context) {
        super(context, name, null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable=  "CREATE TABLE " + name + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + naziv+" TEXT)";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
