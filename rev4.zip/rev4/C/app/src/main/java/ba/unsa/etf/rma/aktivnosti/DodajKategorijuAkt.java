package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

import static android.content.DialogInterface.BUTTON_NEUTRAL;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kategorije;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {

    public class KreirajDokumentKategorijaTask extends AsyncTask<String,Void,Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            try{
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                Log.d("EMINA",TOKEN);
                String url="https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kategorije?access_token=";

                URL urlObj=new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn= (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept","application/json");
                //conn.setRequestProperty("User-Agent","Mozilla/5.0 ( compatible ) ");

                String dokument="{  \"fields\": {\n" +
                        "        \"idIkonice\": {\n" +
                        "          \"integerValue\": \""+k.getId()+"\"\n" +
                        "        },\n" +
                        "        \"naziv\": {\n" +
                        "          \"stringValue\": \""+k.getNaziv()+"\"\n" +
                        "        }\n" +
                        "      }}";

                try(OutputStream os= conn.getOutputStream()){
                    byte[] input= dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = conn.getResponseCode();

                InputStream odgovor= conn.getInputStream();
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response= new StringBuilder();
                    String responseLine=null;
                    while((responseLine = br.readLine())!= null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR",response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    private Button btnSpasi;
    private EditText kat;
    private Kategorija k=new Kategorija();
    private IconDialog iconDialog;
    private Icon[] selectedIcons;
    private Button btnDodajIkonu;
    private EditText ikona;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_dodaj_kategoriju);
        iconDialog= new IconDialog();
        btnDodajIkonu=(Button) findViewById(R.id.btnDodajIkonu);
        kat= (EditText) findViewById(R.id.etNaziv);
        btnSpasi=(Button) findViewById(R.id.btnDodajKategoriju);
        ikona=(EditText) findViewById(R.id.etIkona);
        ikona.setEnabled(false);
        ikona.setFocusable(false);
        btnDodajIkonu.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });


        btnSpasi.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean b=false;
                for(Kategorija ko: kategorije){
                    if(ko.getNaziv().equals(kat.getText().toString()))
                    {
                        b=true;
                        kat.setBackgroundColor(Color.RED);
                        AlertDialog alert= new AlertDialog.Builder(DodajKategorijuAkt.this).create();
                        alert.setTitle("Upozorenje");
                        alert.setMessage("Unesena kategorija već postoji!");
                        alert.setButton(BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                });
                        alert.show();
                        return;

                    }

                }

                if(!b) {
                    k.setNaziv(kat.getText().toString());
                    k.setId(ikona.getText().toString());
                    Log.d("IK", "id: " + k.getId());
                    kategorije.add(k);
                    new KreirajDokumentKategorijaTask().execute("Spirala3");
                    Intent intent = new Intent();
                    setResult(2, intent);
                    finish();
                }
            }
        });

    }


    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
      selectedIcons=icons;
        if(selectedIcons!=null){
            Icon temp = null;
            for(Icon i: selectedIcons) temp=i;
            ikona.setText(""+temp.getId());
        }
    }
}
