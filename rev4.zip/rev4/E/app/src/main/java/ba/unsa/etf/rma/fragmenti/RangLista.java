package ba.unsa.etf.rma.fragmenti;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.DBOpenHelper;
import ba.unsa.etf.rma.klase.NetworkChangeReceiver;
import static com.google.common.collect.Lists.newArrayList;

public class RangLista extends Fragment {

    private static ArrayList<Tuple<String, String, String, String>> rangListaDb = new ArrayList<>();
    private static Map<String, String> kvizLista = new HashMap<>(); //kviz i id rang liste vezane za njega

    public class DobavljanjeListe extends AsyncTask<String, Void, Void> {
        AsyncResponse delegate = null;
        public DobavljanjeListe(AsyncResponse delegate) {
            this.delegate = delegate;
        }
        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;
            String nazivKviza = null;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Rangliste?access_token=";

                String odg = null;
                try {
                    URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                    conn.connect();

                    int code = conn.getResponseCode();
                    InputStream odgovor = conn.getInputStream();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = br.readLine()) != null) {
                            response.append(responseLine.trim());
                        }
                        odg = response.toString();
                        Log.d("ODGOVOR", response.toString());
                    }
                    JSONObject jsonObject = new JSONObject(odg);
                    if(jsonObject.has("documents")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("documents");
                        for(int i = 0; i < jsonArray.length(); i++) {
                            JSONObject document = jsonArray.getJSONObject(i);

                            String[] name = document.getString("name").split("/");
                            String id = name[name.length - 1];

                            JSONObject fields = document.getJSONObject("fields");
                            nazivKviza = fields.getJSONObject("nazivKviza").getString("stringValue");
                            JSONObject lista = fields.getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
                            Iterator<String> iterator = lista.keys();
                            String ime = null, postotak = null;
                            String pozicija = null;
                            while(iterator.hasNext()) {
                                pozicija = iterator.next();
                                JSONObject igrac = lista.getJSONObject(pozicija).getJSONObject("mapValue").getJSONObject("fields");
                                Iterator<String> it = igrac.keys();
                                while(it.hasNext()) {
                                    ime = it.next();
                                    Log.d("IME", ime + " " + pozicija);
                                    JSONObject b = igrac.getJSONObject(ime);
                                    postotak = b.getString("stringValue");
                                    rangListaDb.add(new Tuple<String, String, String, String>(nazivKviza, pozicija, ime, postotak));
                                }
                            }
                            kvizLista.put(nazivKviza, id);
                        }
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void res) {
            delegate.processFinish("");
        }
    }

    public class DodavanjeListe extends AsyncTask<String, Void, String> {

        int pozicija;
        String nazivKviza;
        AsyncResponse delegate;
        String idListe, idListe1;
        boolean kreiranje; //da li se kreira nova rang lista ili se updatuje postojeca

        public DodavanjeListe(boolean kreiranje, int pozicija, String nazivKviza, AsyncResponse delegate, String idListe1) {
            this.kreiranje = kreiranje;
            this.pozicija = pozicija;
            this.nazivKviza = nazivKviza;
            this.delegate = delegate;
            this.idListe1 = idListe1;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url;
                url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Rangliste?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");

                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");


                String dokument = "{\"fields\": {\"lista\": {\"mapValue\": {\"fields\": ";
                dokument += String.format("{\"%s\": {\"mapValue\": {\"fields\": {\"%s\": {\"stringValue\": \"%s\"}}}}}}}, \"nazivKviza\": {\"stringValue\": \"%s\"}}}", pozicija, imeIgraca, procenatTacnih, nazivKviza);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                String odg;
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                    odg = response.toString();
                }
                JSONObject jsonObject = new JSONObject(odg);
                String[] name = jsonObject.getString("name").split("/");
                idListe = name[name.length-1];

                kvizLista.put(nazivKviza, idListe);

            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return idListe;
        }

        @Override
        protected void onPostExecute(String res) {
            delegate.processFinish(res);
        }
    }


    private ListView rangLista;
    private ArrayList<String> listItems = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private String imeIgraca, procenatTacnih, nazivKviza;
    DBOpenHelper helper;

    public RangLista() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_rang_lista, container, false);
        rangLista = (ListView) v.findViewById(R.id.rangLista);
        InformacijeFrag informacijeFrag = (InformacijeFrag) getFragmentManager().findFragmentById(R.id.informacijePlace);
        procenatTacnih = String.valueOf(informacijeFrag.procenat);
        nazivKviza = informacijeFrag.nazivKviza;
        Bundle arguments = getArguments();
        imeIgraca = arguments.getString("ime");

        if(NetworkChangeReceiver.NetworkUtil.getConnectivityStatusString(getContext()) != 0) {

            new DobavljanjeListe(new AsyncResponse() {
                @Override
                public void processFinish(String output) {
                    adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, listItems);
                    rangLista.setAdapter(adapter);

                    for (int i = 0; i < rangListaDb.size() - 1; i++) {
                        if (Double.parseDouble(rangListaDb.get(i).getFourth()) < Double.parseDouble(rangListaDb.get(i + 1).getFourth())) {
                            String temp = rangListaDb.get(i).getFourth();
                            rangListaDb.add(i, new Tuple<>(rangListaDb.get(i).getFirst(), rangListaDb.get(i).getSecond(), rangListaDb.get(i).getThird(), rangListaDb.get(i + 1).getFourth()));
                            rangListaDb.add(i + 1, new Tuple<>(rangListaDb.get(i + 1).getFirst(), rangListaDb.get(i + 1).getSecond(), rangListaDb.get(i + 1).getThird(), temp));
                        }
                    }

                    for (int i = 0; i < rangListaDb.size(); i++) {
                        if (nazivKviza.equals(rangListaDb.get(i).getFirst()))
                            listItems.add(rangListaDb.get(i).getSecond() + ". " + rangListaDb.get(i).getThird() + " " + rangListaDb.get(i).getFourth() + "%");
                    }

                    listItems.add("1. " + imeIgraca + " " + procenatTacnih + "%");



                    if (!kvizLista.containsKey(nazivKviza)) {
                        new DodavanjeListe(true, 1, nazivKviza, new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {

                            }
                        }, null).execute(" ");
                    } else {
                        new DodavanjeListe(false, 1, nazivKviza, new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {

                            }
                        }, kvizLista.get(nazivKviza)).execute(" ");
                    }

                    adapter.notifyDataSetChanged();
                }
            }).execute(" ");
        } else {
            helper = new DBOpenHelper(getActivity(), DBOpenHelper.DATABASE_NAME, null, 1);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DBOpenHelper.RL_IGRAC, imeIgraca);
            values.put(DBOpenHelper.RL_SCORE, procenatTacnih);
            values.put(DBOpenHelper.RL_KVIZ,  nazivKviza);
            db.insert(DBOpenHelper.DATABASE_TABLE3,null, values);

            Cursor res = helper.sveTabele(DBOpenHelper.DATABASE_TABLE3);
            Map<Pair<String, String>, String> rListe = new HashMap<>(); //(igrac, score), naziv kviza
            if(res.getCount() != 0) {
                while(res.moveToNext()) {
                    String igrac = res.getString(1);
                    String score = res.getString(2);
                    String kvizNaziv = res.getString(3);
                    rListe.put(new Pair<>(igrac, score), kvizNaziv);
                }
            }
            ArrayList<Pair<String, String>> rangListeSQL = new ArrayList<>();
            for(Map.Entry<Pair<String, String>, String> i : rListe.entrySet()) {
                if(i.getValue().equals(nazivKviza))
                    rangListeSQL.add(i.getKey());
            }

            Collections.sort(rangListeSQL, new Comparator<Pair<String, String>>() {
                @Override
                public int compare(Pair<String, String> o1, Pair<String, String> o2) {
                    return (int) (Double.parseDouble(o2.second) - Double.parseDouble(o1.second));
                }
            });

            for(int i = 0; i < rangListeSQL.size(); i++) {
                String s = String.format("%s. %s %s%%", i + 1, rangListeSQL.get(i).first, rangListeSQL.get(i).second);
                listItems.add(s);
            }

            adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, listItems);
            rangLista.setAdapter(adapter);
        }
        return v;
    }
}
