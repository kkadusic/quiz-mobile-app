package ba.unsa.etf.rma.klase;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;


public class NetworkChangeReceiver extends BroadcastReceiver {

    public static class NetworkUtil  {
        public static final int TYPE_WIFI = 1;
        public static final int TYPE_MOBILE = 2;
        public static final int TYPE_NOT_CONNECTED = 0;
        private static final int NETWORK_STATUS_WIFI = 1;
        private static final int NETWORK_STATUS_MOBILE = 2;
        private static final int NETWORK_STATUS_NOT_CONNECTED = 0;

        public static int getConnectivityStatus (Context context) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if(activeNetworkInfo != null) {
                if(activeNetworkInfo.getType() == TYPE_WIFI)
                    return TYPE_WIFI;
                if(activeNetworkInfo.getType() == ConnectivityManager.TYPE_MOBILE)
                    return TYPE_MOBILE;
            }
            return TYPE_NOT_CONNECTED;
        }
        public static int getConnectivityStatusString (Context context) {
            int connectivity = NetworkUtil.getConnectivityStatus(context);
            int status = 0;
            if(connectivity == NetworkUtil.TYPE_WIFI)
                status = NETWORK_STATUS_WIFI;
            else if(connectivity == NetworkUtil.TYPE_MOBILE)
                status = NETWORK_STATUS_MOBILE;
            else if(connectivity == NetworkUtil.TYPE_NOT_CONNECTED)
                status = NETWORK_STATUS_NOT_CONNECTED;
            return status;
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        int status = NetworkUtil.getConnectivityStatusString(context);
        if("android.net.conn.CONNECTIVITY_CHANGED".equals(intent.getAction())) {
            if (status == NetworkUtil.NETWORK_STATUS_NOT_CONNECTED)
                Log.d("INTERNET", "NEMMA");
            else
                Log.d("INTERNET", "IMA");
        }
    }
}
