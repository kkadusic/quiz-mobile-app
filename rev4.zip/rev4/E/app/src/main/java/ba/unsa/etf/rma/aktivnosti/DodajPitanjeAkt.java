package ba.unsa.etf.rma.aktivnosti;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.AdapterZaOdgovore;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.DBOpenHelper;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.adjustPitanja;
import static com.google.common.collect.Lists.newArrayList;

public class DodajPitanjeAkt extends AppCompatActivity {

    public class DodavanjePitanja extends AsyncTask<String, Void, String> {
        Pitanje p;
        AsyncResponse delegate = null;

       public DodavanjePitanja(Pitanje pitanje, AsyncResponse delegate) {
            p = new Pitanje(pitanje.getNaziv(), pitanje.getTekstPitanja(), pitanje.getOdgovori(), pitanje.getTacan());
            this.delegate = delegate;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            String idPitanja = null;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = String.format("{ \"fields\": {\"indexTacnog\": {\"integerValue\": %s}, \"naziv\": {\"stringValue\": \"%s\"}, \"odgovori\": {\"arrayValue\": {\"values\": [", p.nadjiIndexTacnog(), p.getNaziv());

                int i = 0;
                while(i < p.getOdgovori().size()) {
                    dokument += String.format("{\"stringValue\": \"%s\"}", p.getOdgovori().get(i));
                    if(i != p.getOdgovori().size() - 1)
                        dokument += ", ";
                    i++;
                }
                dokument += "]}}}}";

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                String odg;
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());

                    odg = response.toString();
                }

                JSONObject jsonObject = new JSONObject(odg);
                String[] name = jsonObject.getString("name").split("/");
                idPitanja = name[name.length-1];

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return idPitanja;
        }

        @Override
        protected void onPostExecute(String s) {
            delegate.processFinish(s);
        }
    }

    private ListView listViewOdgovori;
    private EditText unosNazivaPitanja, unosTekstaOdgovora;
    private Button dodajOdgovorBtn, dodajTacanBtn, dodajPitanjeBtn;

    public List<Pair<String, Boolean>> odgovori = new ArrayList<>();
    public Pitanje pitanje = new Pitanje();

    private DBOpenHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        helper = new DBOpenHelper(this, DBOpenHelper.DATABASE_NAME, null, 1);

        listViewOdgovori = (ListView) findViewById(R.id.lvOdgovori);
        unosNazivaPitanja = (EditText) findViewById(R.id.etNaziv);

        unosTekstaOdgovora = (EditText) findViewById(R.id.etOdgovor);
        dodajOdgovorBtn = (Button) findViewById(R.id.btnDodajOdgovor);
        dodajTacanBtn = (Button) findViewById(R.id.btnDodajTacan);
        dodajPitanjeBtn = (Button) findViewById(R.id.btnDodajPitanje);


        final AdapterZaOdgovore adapter = new AdapterZaOdgovore(this,0, odgovori);
        listViewOdgovori.setAdapter(adapter);



        dodajOdgovorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (unosTekstaOdgovora.getText().toString().isEmpty()) {
                    unosTekstaOdgovora.setBackgroundColor(Color.RED);
                } else if (odgovori.contains(new Pair<String, Boolean> (unosTekstaOdgovora.getText().toString(), false))
                || odgovori.contains(new Pair<String, Boolean> (unosTekstaOdgovora.getText().toString(), true))) {
                    unosTekstaOdgovora.setBackgroundColor(Color.RED);
                } else {
                    unosTekstaOdgovora.setBackgroundColor(0);
                    odgovori.add(new Pair(unosTekstaOdgovora.getText().toString(), false));
                    adapter.notifyDataSetChanged();
                    unosTekstaOdgovora.setText("");
                }
            }
        });

        dodajPitanjeBtn.setEnabled(false);
        dodajTacanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (unosTekstaOdgovora.getText().toString().isEmpty()) {
                    unosTekstaOdgovora.setBackgroundColor(Color.RED);
                } else if(odgovori.contains(new Pair<String, Boolean> (unosTekstaOdgovora.getText().toString(), false))) {
                    unosTekstaOdgovora.setBackgroundColor(Color.RED);
                } else {
                    dodajPitanjeBtn.setEnabled(true);
                    unosTekstaOdgovora.setBackgroundColor(0);
                    odgovori.add(new Pair(unosTekstaOdgovora.getText().toString(), true));
                    //tacan odgovor na pitanje
                    pitanje.setTacan(unosTekstaOdgovora.getText().toString());
                    adapter.notifyDataSetChanged();
                    unosTekstaOdgovora.setText("");
                    dodajTacanBtn.setEnabled(false);
                }
            }
        });

        dodajPitanjeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkInternetConnection()) {
                    //odgovori na pitanje
                    ArrayList<String> odg = new ArrayList<>();
                    for (Pair<String, Boolean> par : odgovori) {
                        odg.add(par.first);
                    }
                    pitanje.setOdgovori(odg);
                    if (unosNazivaPitanja.getText().toString().isEmpty()) {
                        unosNazivaPitanja.setBackgroundColor(Color.RED);
                    } else if (KvizoviAkt.daLiPostojiPitanje(KvizoviAkt.pitanjaDatabase, unosNazivaPitanja.getText().toString())) {
                        unosNazivaPitanja.setBackgroundColor(Color.RED);
                    } else {
                        unosTekstaOdgovora.setBackgroundColor(0);
                        unosNazivaPitanja.setBackgroundColor(0);

                        //naziv pitanja
                        pitanje.setNaziv(unosNazivaPitanja.getText().toString());
                        pitanje.setTekstPitanja(unosNazivaPitanja.getText().toString());

                        Intent i = getIntent();
                        i.putExtra("nazivPitanja", pitanje.getNaziv());//unosNazivaPitanja.getText().toString());
                        i.putExtra("textPitanja", pitanje.getTekstPitanja());//unosNazivaPitanja.getText().toString());
                        i.putStringArrayListExtra("spisakOdgovora", pitanje.dajRandomOdgovore());
                        i.putExtra("tacanOdgovor", (Serializable) pitanje.getTacan());

                        new DodavanjePitanja(pitanje, new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {
                                KvizoviAkt.pitanjaDatabase.put(pitanje, output);
                                KvizoviAkt.pitanjaApp.put(pitanje, output);
                                SQLiteDatabase db = helper.getWritableDatabase();
                                ContentValues values = new ContentValues(); values.put(DBOpenHelper.PITANJE_IDdb, output);
                                values.put(DBOpenHelper.PITANJE_NAZIV, pitanje.getNaziv());
                                values.put(DBOpenHelper.PITANJE_TEKST, pitanje.getNaziv());
                                values.put(DBOpenHelper.PITANJE_ODGOVORI, adjustPitanja(pitanje.getOdgovori()));
                                values.put(DBOpenHelper.PITANJE_TACAN, pitanje.getOdgovori().get(pitanje.getIndexTacnog()));
                                db.insert(DBOpenHelper.DATABASE_TABLE1, null, values);

                            }
                        }).execute("proba1");
                        setResult(DodajPitanjeAkt.RESULT_OK, i);
                        finish();
                    }
                }
            }
        });

        listViewOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(odgovori.get(position).second) dodajTacanBtn.setEnabled(true);
                odgovori.remove(position);
                adapter.notifyDataSetChanged();
            }
        });

    }
    private boolean checkInternetConnection() {
        ConnectivityManager conMgr = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);
        // ARE WE CONNECTED TO THE NET
        return  conMgr.getActiveNetworkInfo() != null && conMgr.getActiveNetworkInfo().isAvailable() && conMgr.getActiveNetworkInfo().isConnected();
    }
}
