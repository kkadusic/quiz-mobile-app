package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.io.Serializable;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.AdapterZaGridView;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;


public class DetailFrag extends Fragment {

    private GridView gridView;
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    ArrayList<Kviz> sviKvizovi = new ArrayList<>();
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    String kategorija;
    int position = 0;

    public DetailFrag() {

    }

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_detail, container, false);
        gridView = (GridView) v.findViewById(R.id.gridKvizovi);
        if(getArguments() != null && getArguments().containsKey("kvizovi")) {
            kvizovi = getArguments().getParcelableArrayList("kvizovi");
            sviKvizovi = getArguments().getParcelableArrayList("sviKvizovi");
            kategorije = getArguments().getParcelableArrayList("kategorije");
            kategorija = ((Kategorija)getArguments().getParcelable("kategorija")).getNaziv();
            AdapterZaGridView adapter;
            if(kategorija.equals("Svi"))
                adapter = new AdapterZaGridView(getActivity(), R.layout.grid_view_item, sviKvizovi);
            else
                adapter = new AdapterZaGridView(getActivity(), R.layout.grid_view_item, kvizovi);
            gridView.setAdapter(adapter);
        }

        for(int i = 0; i < kategorije.size(); i++)
            if(kategorije.get(i).getNaziv().equals(kategorija)) {
                position = i;
                break;
            }

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position1, long id) {
                Intent intent = new Intent(getContext(), DodajKvizAkt.class);
                intent.putExtra("kategorije", (Serializable) kategorije);
                intent.putExtra("sviKvizovi", (Serializable) sviKvizovi);
                if (position == kategorije.size() - 1) {
                    if (position1 == sviKvizovi.size() - 1) {
                        intent.putExtra("kreiranje", true);
                    } else {
                        intent.putExtra("kreiranje", false);
                        intent.putExtra("pozicija", position1);
                        Kviz posalji = kvizovi.get(position1);
                        intent.putExtra("naziv", posalji.getNaziv());
                        intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                        intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                    }
                } else {
                    if (position1 == kvizovi.size() - 1) {
                        intent.putExtra("kreiranje", true);
                    } else {
                        intent.putExtra("kreiranje", false);
                        intent.putExtra("pozicija", position1);
                        Kviz posalji = kvizovi.get(position1);
                        intent.putExtra("naziv", posalji.getNaziv());
                        intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                        intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                    }
                }
                DetailFrag.this.startActivityForResult(intent, 3);
                return true;
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position1, long id) {
                if (position == kategorije.size() - 1) {
                    if (position1 != sviKvizovi.size() - 1) {
                        Intent i = new Intent(getContext(), IgrajKvizAkt.class);
                        i.putExtra("kviz", (Parcelable) sviKvizovi.get(position1));
                        DetailFrag.this.startActivity(i);
                    }
                } else if(position1 != kvizovi.size() - 1) {
                    Intent i = new Intent(getContext(), IgrajKvizAkt.class);
                    i.putExtra("kviz", (Parcelable) kvizovi.get(position1));
                    DetailFrag.this.startActivity(i);
                }
            }
        });
        return v;
    }

}
