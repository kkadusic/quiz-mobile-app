package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "baza.db";
    public static final String DATABASE_TABLE = "Kviz";
    public static final String KVIZ_ID = "_id";
    public static final String KVIZ_IDdb ="iddb";
    public static final String KVIZ_NAZIV ="naziv";
    public static final String KVIZ_PITANJA ="pitanja"; //idevi pitanja odvojeni zarezom
    public static final String KVIZ_KATEGORIJA = "kategorijaid";

    public static final String DATABASE_TABLE1 = "Pitanje";
    public static final String PITANJE_ID ="_id";
    public static final String PITANJE_IDdb ="iddb";
    public static final String PITANJE_NAZIV ="naziv";
    public static final String PITANJE_TEKST ="tekstpitanja";
    public static final String PITANJE_ODGOVORI = "odgovori"; //odgovori odvojeni zarezom
    public static final String PITANJE_TACAN = "tacan";

    public static final String DATABASE_TABLE2 = "Kategorija";
    public static final String KATEGORIJA_ID ="_id";
    public static final String KATEGORIJA_IDdb ="iddb";
    public static final String KATEGORIJA_NAZIV ="naziv";
    public static final String IKONICA_ID ="id";

    public static final String DATABASE_TABLE3 = "RangLista";
    public static final String RL_ID = "_id";
    public static final String RL_IGRAC = "ime";
    public static final String RL_SCORE = "score";
    public static final String RL_KVIZ = "naziv_kviza";

    private static final String CREATE_KVIZ = "create table " +
            DATABASE_TABLE + "(" + KVIZ_ID +
            " integer primary key autoincrement, " +
            KVIZ_IDdb + " text not null, " +
            KVIZ_NAZIV + " text not null, " +
            KVIZ_PITANJA + " text not null, " +
            KVIZ_KATEGORIJA + " text not null);";

    private static final String CREATE_PITANJE = "create table " +
            DATABASE_TABLE1 + "(" + PITANJE_ID +
            " integer primary key autoincrement, " +
            PITANJE_IDdb + " text not null, " +
            PITANJE_NAZIV + " text not null, " +
            PITANJE_TEKST + " text not null, " +
            PITANJE_ODGOVORI + " text not null, " +
            PITANJE_TACAN + " text not null);";

    private static final String CREATE_KATEGORIJA = "create table " +
            DATABASE_TABLE2 + "(" + KATEGORIJA_ID +
            " integer primary key autoincrement, " +
            KATEGORIJA_IDdb + " text not null, " +
            KATEGORIJA_NAZIV + " text not null, " +
            IKONICA_ID + " text not null);";

    private static final String CREATE_RL = "create table " +
            DATABASE_TABLE3 + " (" + RL_ID +
            " integer primary key autoincrement, " +
            RL_IGRAC + " text not null, " +
            RL_SCORE + " text not null, " +
            RL_KVIZ + " text not null);";


    public DBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    //    SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_KVIZ);
        db.execSQL(CREATE_PITANJE);
        db.execSQL(CREATE_KATEGORIJA);
        db.execSQL(CREATE_RL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Brisanje stare verzije
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE1);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE2);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE3);
        // Kreiranje nove
        onCreate(db);
    }

    public Cursor sveTabele (String nazivTabele) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from " + nazivTabele, null);
    }
}
