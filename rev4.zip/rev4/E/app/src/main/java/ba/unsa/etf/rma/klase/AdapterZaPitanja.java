package ba.unsa.etf.rma.klase;

import android.content.Context;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;


public class AdapterZaPitanja extends ArrayAdapter<Pitanje> {

    private Context context;
    private List<Pitanje> list = new ArrayList<>();

    public AdapterZaPitanja(@NonNull Context context, @NonNull List<Pitanje> objects) {
        super(context, 0, objects);
        this.context = context;
        list = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.list_item_kviz, parent, false);
        }

        Pitanje trenutnoPitanje = list.get(position);

        ImageView image = (ImageView) listItem.findViewById(R.id.idKategorije);
        image.setImageResource(R.drawable.add_icon);

        TextView naziv = (TextView) listItem.findViewById(R.id.nazivKviza);
        naziv.setText(trenutnoPitanje.getNaziv());
        return listItem;
    }
}
