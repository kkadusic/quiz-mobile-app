package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Parcelable;

import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListFrag;
import ba.unsa.etf.rma.klase.AdapterZaKvizove;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.CustomDialog;
import ba.unsa.etf.rma.klase.DBOpenHelper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static com.google.common.collect.Lists.newArrayList;

public class KvizoviAkt extends AppCompatActivity implements ListFrag.OnItemClick {

    private static final int REQUEST = 0;
    public static Map<Pitanje, String> pitanjaDatabase = new HashMap<>(); //pitanje sa atributima datim u bazi (String - naziv, ArrayList<String> - idevi pitanja, String - id kategorije)
    public static Map<Object, String> pitanjaApp = new HashMap<>(); //pitanje ciji su atributi iz prethodnih spirala
    public static Map<Kviz, String> kvizoviDatabase = new HashMap<>(); //vazi isto sto i za pitanje
    public static Map<Pitanje, String> mogucaPitanjaDatabase = new HashMap<>();
    public static ArrayList<Kviz> kvizoviApp = new ArrayList<>();
    public static Map<Kategorija, String> kategorijeDatabase = new HashMap<>();
    public static Map<Object, String> kategorijeApp = new HashMap<>();
    private Map<Kviz, String> selektovaniKvizovi = new HashMap<>();
    private DBOpenHelper helper;


    public class DobavljanjePoKategoriji extends AsyncTask<String, Void, Void> {
        private String idKatIzSpinera;
        private AsyncResponse delegate = null;

        public DobavljanjePoKategoriji(String id, AsyncResponse delegate) {
            idKatIzSpinera = id;
            this.delegate = delegate;
        }

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;
            String query = String.format("{\"structuredQuery\": {\"where\": {\"fieldFilter\": {\"field\" : {\"fieldPath\": \"idKategorije\"}, \"op\":\"EQUAL\"," +
                    "\"value\": {\"stringValue\": \"%s\"}}}, \"select\": {\"fields\": [{\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, " +
                    "{\"fieldPath\": \"pitanja\"}]}, \"from\": [{\"collectionId\": \"Kvizovi\"}], \"limit\": 1000}}", idKatIzSpinera);
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents:runQuery?access_token=";
                try {
                    URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                    conn.setDoOutput(true);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Accept", "application/json");
                    try (OutputStream os = conn.getOutputStream()) {
                        byte[] input = query.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    int code = conn.getResponseCode();
                    InputStream odgovor = conn.getInputStream();
                    String odg;
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = br.readLine()) != null) {
                            response.append(responseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                        odg = response.toString();
                    }

                    odg = "{\"documents\": " + odg + "}";


                    JSONObject jsonObject = new JSONObject(odg);
                    JSONArray documents = jsonObject.getJSONArray("documents");
                    for(int i = 0; i < documents.length(); i++) {
                        JSONObject document1 = documents.getJSONObject(i);
                        if (document1.has("document")) {
                            JSONObject document = document1.getJSONObject("document");
                            ArrayList<String> idPitanja = new ArrayList<>();
                            String[] name = document.getString("name").split("/");
                            String id = name[name.length - 1];
                            JSONObject fields = document.getJSONObject("fields");
                            String idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
                            String naziv = fields.getJSONObject("naziv").getString("stringValue");
                            JSONObject jsonPitanjaObj = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
                            if(jsonPitanjaObj.has("values")) {
                                JSONArray jsonPitanja = jsonPitanjaObj.getJSONArray("values");
                                for (int j = 0; j < jsonPitanja.length(); j++) {
                                    idPitanja.add(jsonPitanja.getJSONObject(j).getString("stringValue"));
                                }
                            }
                            selektovaniKvizovi.put(new Kviz(naziv, idKategorije, idPitanja), id);
                        }
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            delegate.processFinish("");
        }
    }

    //dobavljanje Kvizova, Kategorija i Pitanja iz Firebase
    public class DobavljanjeKolekcija extends AsyncTask<String, Void, String> {

        AsyncResponse delegate = null;

        public DobavljanjeKolekcija(AsyncResponse delegate) {
            this.delegate = delegate;
        }

        @Override
        protected String doInBackground(String... params) {
            GoogleCredential credentials;
            String idKviza = null;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kvizovi?access_token=";
                String odg = pristupBazi(url, TOKEN);

                JSONObject jsonObject = new JSONObject(odg);
                JSONArray documents;
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        String id = null;
                        ArrayList<String> idPitanja = new ArrayList<>();
                        String[] name = document.getString("name").split("/");
                        id = name[name.length - 1];
                        idKviza = id;
                        JSONObject fields = document.getJSONObject("fields");
                        String idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        JSONObject jsonPitanjaObj = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
                        if (jsonPitanjaObj.has("values")) {
                            JSONArray jsonPitanja = jsonPitanjaObj.getJSONArray("values");
                            for (int j = 0; j < jsonPitanja.length(); j++) {
                                idPitanja.add(jsonPitanja.getJSONObject(j).getString("stringValue"));
                            }
                        }
                        if (!daLiPostojiKviz(kvizoviDatabase, id))
                            kvizoviDatabase.put(new Kviz(naziv, idKategorije, idPitanja), id);

                    }
                }
                url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Pitanja?access_token=";
                odg = pristupBazi(url, TOKEN);
                jsonObject = new JSONObject(odg);
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    int indexTacnog;
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        ArrayList<String> odgovori = new ArrayList<>();
                        String[] name = document.getString("name").split("/");
                        String id = name[name.length - 1];
                        JSONObject fields = document.getJSONObject("fields");
                        indexTacnog = fields.getJSONObject("indexTacnog").getInt("integerValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        JSONObject jsonOdgovoriObj = fields.getJSONObject("odgovori").getJSONObject("arrayValue");
                        JSONArray jsonOdgovori = jsonOdgovoriObj.getJSONArray("values");
                        for (int j = 0; j < jsonOdgovori.length(); j++) {
                            odgovori.add(jsonOdgovori.getJSONObject(j).getString("stringValue"));
                        }

                        pitanjaDatabase.put(new Pitanje(naziv, indexTacnog, odgovori), id);
                    }
                }

                url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kategorije?access_token=";
                odg = pristupBazi(url, TOKEN);
                jsonObject = new JSONObject(odg);
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        String[] name = document.getString("name").split("/");
                        String id = name[name.length - 1];
                        JSONObject fields = document.getJSONObject("fields");
                        int idIkonice = fields.getJSONObject("idIkonice").getInt("integerValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        kategorijeDatabase.put(new Kategorija(naziv, Integer.toString(idIkonice)), id);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return idKviza;
        }

        @Override
        protected void onPostExecute(String res) {
            delegate.processFinish(res);
        }
    }

    private Spinner spinner;
    private ListView listView;

    private ArrayList<Kategorija> dodaneKategorije = new ArrayList<>();
    public ArrayList<Kviz> kvizovi = new ArrayList<>();
    AdapterZaKvizove kvizAd;
    ArrayAdapter<Kategorija> spinerAd;

    private Boolean siriL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);

        spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
        listView = (ListView) findViewById(R.id.lvKvizovi);

        dodaneKategorije.add(new Kategorija("Svi", "54"));
        kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
        helper = new DBOpenHelper(this, DBOpenHelper.DATABASE_NAME, null, 1);


        if(checkInternetConnection()) {

            new DobavljanjeKolekcija(new AsyncResponse() {
                @Override
                public void processFinish(String output) {
                    dodaneKategorije.addAll(0, izdvojiKategorije());
                    spinerAd.notifyDataSetChanged();
                    spinner.setSelection(dodaneKategorije.size() - 1);
                    izdvojiPitanja(pitanjaDatabase);
                    kvizovi.addAll(0, izdvojiKvizove(kvizoviDatabase));
                    kvizAd.notifyDataSetChanged();
                    izdvojiMoguca();


                    SQLiteDatabase db = helper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    for(Map.Entry<Kviz, String> k : kvizoviDatabase.entrySet()) {
                        values.put(DBOpenHelper.KVIZ_IDdb, k.getValue());
                        values.put(DBOpenHelper.KVIZ_NAZIV, k.getKey().getNaziv());
                        values.put(DBOpenHelper.KVIZ_PITANJA, adjustPitanja(k.getKey().getPitanjaId()));
                        if(k.getKey().getKategorijaId() != null)
                            values.put(DBOpenHelper.KVIZ_KATEGORIJA, k.getKey().getKategorijaId());
                        else
                            values.put(DBOpenHelper.KVIZ_KATEGORIJA, "Svi");
                        db.insert("Kviz",null, values);

                    }

                    values = new ContentValues();
                    for(Map.Entry<Pitanje, String> k : pitanjaDatabase.entrySet()) {
                        values.put(DBOpenHelper.PITANJE_IDdb, k.getValue());
                        values.put(DBOpenHelper.PITANJE_NAZIV, k.getKey().getNaziv());
                        values.put(DBOpenHelper.PITANJE_TEKST, k.getKey().getNaziv());
                        values.put(DBOpenHelper.PITANJE_ODGOVORI, adjustPitanja(k.getKey().getOdgovori()));
                        values.put(DBOpenHelper.PITANJE_TACAN, k.getKey().getOdgovori().get(k.getKey().getIndexTacnog()));
                        db.insert(DBOpenHelper.DATABASE_TABLE1, null, values);
                    }


                    values = new ContentValues();
                    for(Map.Entry<Kategorija, String> k : kategorijeDatabase.entrySet()) {
                        values.put(DBOpenHelper.KATEGORIJA_NAZIV, k.getKey().getNaziv());
                        values.put(DBOpenHelper.KATEGORIJA_IDdb, k.getValue());
                        values.put(DBOpenHelper.IKONICA_ID, k.getKey().getId());
                        db.insert(DBOpenHelper.DATABASE_TABLE2, null, values);
                    }

                }
            }).execute(" ");
        } else {
            Cursor res = helper.sveTabele(DBOpenHelper.DATABASE_TABLE);
            if(res.getCount() != 0) {
                while(res.moveToNext()) {
                    String idFB = res.getString(1);
                    String naziv = res.getString(2);
                    ArrayList<String> pitanjaID = stringToList(res.getString(3));
                    String kategorijaID = res.getString(4);
                    Kviz k = new Kviz(naziv, kategorijaID, pitanjaID);
                    if(!postojiLiKviz(kvizoviDatabase, idFB))
                        kvizoviDatabase.put(k, idFB);
                }
            }
            res = helper.sveTabele(DBOpenHelper.DATABASE_TABLE1);
            if(res.getCount() != 0) {
                while(res.moveToNext()) {
                    String idFB = res.getString(1);
                    String naziv = res.getString(2);
                    ArrayList<String> odgovori = stringToList(res.getString(4));
                    String tacan = res.getString(5);
                    Pitanje p = new Pitanje(naziv, odgovori.indexOf(tacan), odgovori);
                    if(!postojiLiPitanje(pitanjaDatabase, idFB))
                        pitanjaDatabase.put(p, idFB);
                }
            }
            res = helper.sveTabele(DBOpenHelper.DATABASE_TABLE2);
            if(res.getCount() != 0) {
                while(res.moveToNext()) {
                    String idFB = res.getString(1);
                    String naziv = res.getString(2);
                    String ikonica = res.getString(3);
                    Kategorija k = new Kategorija(naziv, ikonica);
                    if(!postojiLiKategorija(kategorijeDatabase, idFB))
                       kategorijeDatabase.put(k, idFB);
                }
            }

            dodaneKategorije.addAll(0, izdvojiKategorije());
            spinerAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dodaneKategorije);
            spinerAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinerAd);
            spinner.setSelection(dodaneKategorije.size() - 1);
            izdvojiPitanja(pitanjaDatabase);
            kvizovi.addAll(0, izdvojiKvizove(kvizoviDatabase));
            kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi);
            listView.setAdapter(kvizAd);
            kvizAd.notifyDataSetChanged();
            izdvojiMoguca();
        }


        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_CALENDAR}, REQUEST);
        }
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(Uri.parse("content://com.android.calendar/events"), new String[]{ "calendar_id", "title", "description", "dtstart", "dtend", "eventLocation" }, null, null, null);
        final List<Pair<Date, Date>> zakazaniDogadjaji = new ArrayList<>();
        if(cursor != null) {
            cursor.moveToFirst();
            String[] CalNames = new String[cursor.getCount()];
            for (int i = 0; i < CalNames.length; i++) {
                Date startDate = new Date(cursor.getLong(3));
                Date endDate = new Date(cursor.getLong(4));
                zakazaniDogadjaji.add(new Pair<>(startDate, endDate));
                cursor.moveToNext();
            }
            cursor.close();
        }

        if (spinner != null || listView != null) {

            spinerAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dodaneKategorije);
            spinerAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinerAd);


            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(final AdapterView<?> parent, View view, final int position, long id) {
                    final ArrayList<Kviz> kvizovi1 = new ArrayList<>(); //selektovani
                    if (position == dodaneKategorije.size() - 1) {
                        izdvojiMoguca();
                        izdvojiPitanja(pitanjaDatabase);
                        kvizovi = izdvojiKvizove(kvizoviDatabase);
                        kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                        kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi);
                    } else {
                        if(checkInternetConnection()) {
                            new DobavljanjePoKategoriji(kategorijeApp.get(dodaneKategorije.get(position)), new AsyncResponse() {
                                @Override
                                public void processFinish(String output) {
                                    izdvojiPitanja(pitanjaDatabase);
                                    kvizovi1.addAll(0, izdvojiKvizove(selektovaniKvizovi));
                                    kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                                    kvizAd.notifyDataSetChanged();
                                    selektovaniKvizovi.clear();
                                }
                            }).execute(" ");
                            kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi1);
                        } else {
                            for(int i = 0; i < kvizoviApp.size(); i++)
                                if(kvizoviApp.get(i).getKategorija() != null && kvizoviApp.get(i).getKategorija().getNaziv().equals(dodaneKategorije.get(position).getNaziv()) && !kvizovi1.contains(kvizoviApp.get(i)))
                                    kvizovi1.add(0, kvizoviApp.get(i));
                            kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi1);
                            kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                            kvizAd.notifyDataSetChanged();
                        }
                       // kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi1);
                    }
                    listView.setAdapter(kvizAd);

                    listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> parent1, View view1, int position1, long id1) {
                            ArrayList<Kviz> kvizovi1 = new ArrayList<>();
                            for (int i = 0; i < kvizovi.size() - 1; i++) {
                                if (dodaneKategorije.get(position).getNaziv().equals(kvizovi.get(i).getKategorija().getNaziv()))
                                    kvizovi1.add(kvizovi.get(i));
                            }

                            kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                            Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            intent.putExtra("kategorije", (Serializable) dodaneKategorije);
                            intent.putExtra("sviKvizovi", (Serializable) kvizovi);
                            if (position == dodaneKategorije.size() - 1) {
                                if (position1 == kvizovi.size() - 1) {
                                    intent.putExtra("dodavanje", true);
                                } else {
                                    intent.putExtra("dodavanje", false);
                                    intent.putExtra("pozicija", position1);
                                    Kviz posalji = kvizovi.get(position1);
                                    intent.putExtra("naziv", posalji.getNaziv());
                                    intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                                    intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                                }
                            } else {
                                if (position1 == kvizovi1.size() - 1) {
                                    intent.putExtra("dodavanje", true);
                                } else {
                                    intent.putExtra("dodavanje", false);
                                    intent.putExtra("pozicija", position1);
                                    Kviz posalji = kvizovi1.get(position1);
                                    intent.putExtra("naziv", posalji.getNaziv());
                                    intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                                    intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                                }
                            }
                            KvizoviAkt.this.startActivityForResult(intent, 3);
                            return true;
                        }
                    });


                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position2, long id) {
                            if (position == dodaneKategorije.size() - 1) {
                                if (position2 != kvizovi.size() - 1) {
                                    DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                                    Date currentDate = null;
                                    try {
                                        currentDate = dateFormat.parse(dateFormat.format(new Date()));
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                    boolean dozvoliIgranje = true;
                                    int x = (int) Math.ceil(kvizovi.get(position2).getPitanja().size());
                                    x *= 60000;
                                    for(int i = 0; i < zakazaniDogadjaji.size(); i++) {
                                        long y = zakazaniDogadjaji.get(i).first.getTime() - currentDate.getTime(); //u milisec
                                        long preostaloDoKraja = zakazaniDogadjaji.get(i).second.getTime() - currentDate.getTime();

                                        if (y < 0 && preostaloDoKraja > 0) {
                                            dozvoliIgranje = false;
                                            openDialog("Imate trenutno aktivan događaj u kalendaru!");
                                            break;
                                        } else if (y > 0 && y < x) {
                                            dozvoliIgranje = false;
                                            y = TimeUnit.MINUTES.convert(y, TimeUnit.MILLISECONDS) + 1;
                                            openDialog("Imate događaj u kalendaru za " + y + " minuta");
                                            break;
                                        }
                                    }
                                    if(dozvoliIgranje) {
                                        Intent i = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                                        i.putExtra("kviz", (Parcelable) kvizovi.get(position2));
                                        KvizoviAkt.this.startActivity(i);
                                    }
                                }
                            } else if (position2 != kvizovi1.size() - 1) {
                                DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                                Date currentDate = null;
                                try {
                                    currentDate = dateFormat.parse(dateFormat.format(new Date()));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                boolean dozvoliIgranje = true;
                                int x = (int) Math.ceil(kvizovi1.get(position2).getPitanja().size());
                                x *= 60000;
                                for(int i = 0; i < zakazaniDogadjaji.size(); i++) {
                                    long y = zakazaniDogadjaji.get(i).first.getTime() - currentDate.getTime(); //u milisec
                                    long preostaloDoKraja = zakazaniDogadjaji.get(i).second.getTime() - currentDate.getTime();
                                    if (y < 0 && preostaloDoKraja > 0) {
                                        dozvoliIgranje = false;
                                        openDialog("Imate trenutno aktivan događaj u kalendaru!");
                                        break;
                                    } else if (y > 0 && y < x) {
                                        dozvoliIgranje = false;
                                        y = TimeUnit.MINUTES.convert(y, TimeUnit.MILLISECONDS) + 1;
                                        openDialog("“Imate događaj u kalendaru za " + y + " minuta");
                                        break;
                                    }
                                }
                                if(dozvoliIgranje) {
                                    Intent i = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                                    i.putExtra("kviz", (Parcelable) kvizovi1.get(position2));
                                    KvizoviAkt.this.startActivity(i);
                                }
                            }
                        }
                    });
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        } else if (listView == null) {
            siriL = false;

            FragmentManager fragmentManager = getSupportFragmentManager();
            FrameLayout detailPlace = (FrameLayout) findViewById(R.id.detailPlace);
            if (detailPlace != null) {
                siriL = true;
                DetailFrag detailFrag;
                detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);
                if (detailFrag == null) {
                    detailFrag = new DetailFrag();
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }
            }

            ListFrag listFrag = (ListFrag) fragmentManager.findFragmentByTag("Lista");
            if (listFrag == null) {
                listFrag = new ListFrag();
                Bundle argumenti = new Bundle();
                argumenti.putParcelableArrayList("kategorije", dodaneKategorije);
                listFrag.setArguments(argumenti);
                fragmentManager.beginTransaction().replace(R.id.listPlace, listFrag, "Lista").commit();
            } else {
                fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
        }
    }

   @Override
    protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 3 && resultCode == DodajKvizAkt.RESULT_OK) {
            boolean dodavanje = data.getBooleanExtra("dodavanje", false);
            dodaneKategorije.addAll(dodaneKategorije.size() - 1, (ArrayList<Kategorija>) data.getSerializableExtra("noveKategorije"));
            spinerAd.notifyDataSetChanged();
            if(dodavanje) {
                for(int i = 0; i < kvizoviApp.size(); i++)
                    if(!kvizovi.contains(kvizoviApp.get(i)))
                        kvizovi.add(0, kvizoviApp.get(i));
                kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi);
                listView.setAdapter(kvizAd);
                spinner.setSelection(0);

            } else {

                spinner.setSelection(dodaneKategorije.size()-1);
                izdvojiPitanja(pitanjaDatabase);
                kvizovi = izdvojiKvizove(kvizoviDatabase);
                kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                kvizAd = new AdapterZaKvizove(this, android.R.layout.simple_list_item_1, kvizovi);
                listView.setAdapter(kvizAd);
            }

        } else if (requestCode == 3 && resultCode == DodajKvizAkt.RESULT_CANCELED) {
            dodaneKategorije.addAll(dodaneKategorije.size() - 1, (ArrayList<Kategorija>) data.getSerializableExtra("noveKategorije"));
            spinerAd.notifyDataSetChanged();
            spinner.setSelection(dodaneKategorije.size()-1);
        }
    }

    @Override
    public void onItemClicked(int pos) {
        Bundle bundle = new Bundle();
        ArrayList<Kviz> kvizovi1 = new ArrayList<>();
        for(int i = 0; i < kvizovi.size() - 1; i++)
            if(kvizovi.get(i).getKategorija().equals(dodaneKategorije.get(pos)))
                kvizovi1.add(kvizovi.get(i));
        kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));

        bundle.putParcelableArrayList("sviKvizovi", kvizovi);
        bundle.putParcelableArrayList("kvizovi", kvizovi1);
        bundle.putParcelableArrayList("kategorije", dodaneKategorije);
        bundle.putParcelable("kategorija", dodaneKategorije.get(pos));
        DetailFrag detailFrag = new DetailFrag();
        detailFrag.setArguments(bundle);
        if(siriL) {
            getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, detailFrag).addToBackStack(null).commit();
        }
    }

    private static String pristupBazi(String url, String TOKEN) {
        String odg = null;
        try {
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.connect();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                odg = response.toString();
                Log.d("ODGOVOR", response.toString());
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return odg;
    }


    private static ArrayList<Kategorija> izdvojiKategorije() {
        ArrayList<Kategorija> res = new ArrayList<>();
        for(Map.Entry<Kategorija, String> i : kategorijeDatabase.entrySet()) {
            Kategorija kategorija = new Kategorija(i.getKey().getNaziv(), i.getKey().getId());
            res.add(kategorija);
            kategorijeApp.put(kategorija, i.getValue());
        }
        return res;
    }


    public static ArrayList<Pitanje> izdvojiPitanja(Map<Pitanje, String> mapa) {
        ArrayList<Pitanje> res = new ArrayList<>();
        for(Map.Entry<Pitanje, String> i : mapa.entrySet()) {
            Pitanje pitanje = new Pitanje(i.getKey().getNaziv(), i.getKey().getNaziv(), i.getKey().getOdgovori(), i.getKey().getOdgovori().get(i.getKey().getIndexTacnog()));
            res.add(pitanje);
            pitanjaApp.put(pitanje, i.getValue());
        }
        return res;
    }

    //naziv, idkategorije, idpitanja
    public static ArrayList<Kviz> izdvojiKvizove(Map<Kviz, String> mapa) {
        ArrayList<Kviz> res = new ArrayList<>();
        for(Map.Entry<Kviz, String> i : mapa.entrySet()) {
            ArrayList<Pitanje> pitanja = new ArrayList<>();
            String naziv = i.getKey().getNaziv();
            Kategorija kategorija = (Kategorija) getKey(kategorijeApp,  String.valueOf(i.getKey().getKategorijaId()));
            for(int j = 0; j < i.getKey().getPitanjaId().size(); j++)
                pitanja.add((Pitanje)getKey(pitanjaApp, i.getKey().getPitanjaId().get(j)));
            Kviz kviz = new Kviz(naziv, pitanja, kategorija);
            kvizoviApp.add(kviz);
            res.add(0, kviz);
        }
        return res;
    }

    private static Object getKey(Map<Object, String> map, String value) {
        Object res = null;
        for(Map.Entry<Object, String> i : map.entrySet()) {
            if(i.getValue().equals(value))
                res = i.getKey();
        }
        return res;
    }

    public static boolean daLiPostojiKategorija (Map<Kategorija, String> map, String s) {
        for(Map.Entry<Kategorija, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static boolean daLiPostojiKviz (Map<Kviz, String> map, String s) {
        for(Map.Entry<Kviz, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static boolean daLiPostojiPitanje (Map<Pitanje, String> map, String s) {
        for(Map.Entry<Pitanje, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static Kviz dajKvizSaNazivom(Map<Kviz, String> map, String naziv) {
        Kviz k = null;
        for(Map.Entry<Kviz, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    public static Kategorija dajKategorijuSaNazivom(Map<Kategorija, String> map, String naziv) {
        Kategorija k = null;
        for(Map.Entry<Kategorija, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    public static Pitanje dajPitanjeSaNazivom(Map<Pitanje, String> map, String naziv) {
        Pitanje k = null;
        for(Map.Entry<Pitanje, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    private static void izdvojiMoguca () {
        for(Map.Entry<Pitanje, String> p : pitanjaDatabase.entrySet()) {
            boolean dodano = false;
            for(Map.Entry<Kviz, String> k : kvizoviDatabase.entrySet()) {
                if(k.getKey().getPitanjaId().contains(p.getValue())) {
                    dodano = true;
                    break;
                }
            }
            if(!dodano) mogucaPitanjaDatabase.put(p.getKey(), p.getValue());
        }
    }
    public void openDialog(String s) {
        CustomDialog dialog = CustomDialog.newInstance(s);
        dialog.show(getSupportFragmentManager(), "dialog");
    }

    private boolean checkInternetConnection() {
        ConnectivityManager conMgr = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);
        // ARE WE CONNECTED TO THE NET
        return  conMgr.getActiveNetworkInfo() != null && conMgr.getActiveNetworkInfo().isAvailable() && conMgr.getActiveNetworkInfo().isConnected();
    }

    public static String adjustPitanja (ArrayList<String> pitanjes) {
        String res = " ";
        for(int i = 0; i < pitanjes.size(); i++) {
            res += pitanjes.get(i);
            if(i != pitanjes.size() - 1)
                res += ",";
        }
        return res;
    }

    private ArrayList<String> stringToList (String s) {
        String[] strings = s.split(",");
        ArrayList<String> res = new ArrayList<>();
        for(int i = 0; i < strings.length; i++)
            res.add(strings[i].replace(" ", ""));
        return res;
    }

    private static boolean postojiLiKviz (Map<Kviz, String> mapa, String id) {
        for(Map.Entry<Kviz, String> i : mapa.entrySet())
            if(i.getValue().equals(id))
                return true;
        return false;
    }
    private static boolean postojiLiPitanje (Map<Pitanje, String> mapa, String id) {
        for(Map.Entry<Pitanje, String> i : mapa.entrySet())
            if(i.getValue().equals(id))
                return true;
        return false;
    }
    private static boolean postojiLiKategorija (Map<Kategorija, String> mapa, String id) {
        for(Map.Entry<Kategorija, String> i : mapa.entrySet())
            if(i.getValue().equals(id))
                return true;
        return false;
    }
}
