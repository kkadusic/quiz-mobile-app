package ba.unsa.etf.rma.klase;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;

public class CustomDialog extends DialogFragment {
    private String poruka;

    public static CustomDialog newInstance (String s) {
        final Bundle args = new Bundle(1);
        args.putString("poruka", s);
        CustomDialog dialog = new CustomDialog();
        dialog.setArguments(args);
        return dialog;
    }

    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        String s = (String) getArguments().getString("poruka");
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(s)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        return builder.create();
    }


}
