package ba.unsa.etf.rma.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import ba.unsa.etf.rma.klase.Kategorija;
import java.util.ArrayList;

public class SpinnerKategorijaAdapter extends ArrayAdapter {

    int resource;
    Context context;

    public SpinnerKategorijaAdapter(Context context, int resource, ArrayList<Kategorija> kategorije) {
        super(context, resource, kategorije);
        this.resource = resource;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        Kategorija kategorija = (Kategorija) getItem(position);

        TextView textView = convertView.findViewById(android.R.id.text1);

        textView.setText(kategorija.getNaziv());

        return convertView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        Kategorija kategorija = (Kategorija) getItem(position);

        TextView textView = convertView.findViewById(android.R.id.text1);

        textView.setText(kategorija.getNaziv());

        return convertView;
    }
}
