package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Kategorija implements Serializable {
    String naziv;
    String id;
    String idInFirebase;

    public Kategorija() {
    }

    public Kategorija(String naziv, String id, String idInFirebase) {
        this.naziv = naziv;
        this.id = id;
        this.idInFirebase = idInFirebase;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdInFirebase() {
        return idInFirebase;
    }

    public void setIdInFirebase(String idInFirebase) {
        this.idInFirebase = idInFirebase;
    }

    @Override
    public boolean equals(Object obj) {
        return getNaziv().equals(((Kategorija) obj).getNaziv());
    }
}
