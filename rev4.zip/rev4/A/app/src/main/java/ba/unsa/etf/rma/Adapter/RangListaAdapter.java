package ba.unsa.etf.rma.Adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Rang;
import ba.unsa.etf.rma.klase.RangListaKviza;

public class RangListaAdapter extends BaseAdapter {

    ArrayList<Rang> rangList;
    private Context context;

    public RangListaAdapter(Context context, ArrayList<Rang> rangList) {
        this.rangList = rangList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return rangList.size();
    }

    @Override
    public Object getItem(int position) {
        return rangList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = ((IgrajKvizAkt) context).getLayoutInflater().inflate(R.layout.fragment_rang_lista_item, parent, false);

        TextView imeIgraca = convertView.findViewById(R.id.imeIgraca);
        TextView idPozicije = convertView.findViewById(R.id.idPozicije);
        TextView procenatTacnih = convertView.findViewById(R.id.procenatTacnih);

        idPozicije.setText(String.valueOf(position + 1));
        imeIgraca.setText(rangList.get(position).getImeIgraca());
        procenatTacnih.setText(rangList.get(position).getProcenatTacnih()+"%");
        return convertView;
    }

}
