package ba.unsa.etf.rma.aktivnosti;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.util.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ba.unsa.etf.rma.Adapter.KvizAdapter;
import ba.unsa.etf.rma.Adapter.SpinnerKategorijaAdapter;
import ba.unsa.etf.rma.Async.GetRequestAsync;
import ba.unsa.etf.rma.Async.TokenAsync;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.Data.KvizoviDBOpenHelper;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.util.ConnectivityHelper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ExecutionException;

public class KvizoviAkt extends AppCompatActivity {

    ArrayList<Kviz> kvizovi;
    public static ArrayList<Kategorija> kategorije;
    ArrayList<Pitanje> pitanja;

    Kategorija kategorija;
    ListaFrag listaFrag;
    DetailFrag detailFrag;

    SpinnerKategorijaAdapter spinnerKategorijaAdapter;
    KvizAdapter kvizAdapter;
    private KvizoviDBOpenHelper kvizoviDBOpenHelper;

    public static String token = "nepoznat";
    public static GoogleCredential gcredential = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);

        kvizoviDBOpenHelper = new KvizoviDBOpenHelper(getApplicationContext());

        kvizovi = new ArrayList<>();
        kategorije = new ArrayList<>();
        pitanja = new ArrayList<>();

        if (ConnectivityHelper.isNetworkAvailable(this)) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                gcredential = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList(Collections.singleton("https://www.googleapis.com/auth/datastore")));
                if (gcredential == null) Log.w("TOKEN", "GCredential null!");
            } catch (IOException e) {
                Log.w("TOKEN", "GCredential IOe: " + e.getMessage());
                e.printStackTrace();
            }

            TokenAsync tokenAsync = new TokenAsync();
            try {
                token = tokenAsync.execute(gcredential).get().getAccessToken();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Log.d("TOKEN", "Value: " + token);

            getKategorije();
        } else {
            populateFromDatabase();
        }


        Icon icon = IconHelper.getInstance(getApplicationContext()).getIcon(232);
        if (icon == null) Log.w("TESTER", "Still icon null");
        if (icon != null) Log.w("TESTER", "icon !null");
    }

    public void getKategorije() {
        try {
            String responseKategorije = new GetRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kategorije?access_token=" + token).get();
            parseKategorije(responseKategorije);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void parseKategorije(String response) {
        JSONObject katObj;
        try {
            katObj = new JSONObject(response);
            JSONArray docs = katObj.getJSONArray("documents");
            for (int i = 0; i < docs.length(); i++) {
                JSONObject docsObj = new JSONObject(docs.getString(i));
                String idKat = docsObj.getString("name");
                String naziv = docsObj.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                String ikona = String.valueOf(docsObj.getJSONObject("fields").getJSONObject("idIkonice").getInt("integerValue"));
                Data.getInstance().kategorije.add(new Kategorija(naziv, ikona, idKat.substring(73)));
            }
            spasiKategorijeUdatabase(Data.getInstance().kategorije);

            try {
                String responsePitanja = new GetRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Pitanja?access_token=" + token).get();
                parsePitanja(responsePitanja);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } catch (JSONException e) {
            Log.w("SUCCESS", "Kategorije IOe!");
            e.printStackTrace();
        }
    }

    public void getKvizovi() {
        try {
            String responseKvizovi = new GetRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kvizovi?access_token=" + token).get();
            parseKvizovi(responseKvizovi);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void parseKvizovi(String response) {
        Kategorija katKviza = null;
        JSONObject kvizoviObj;
        try {
            kvizoviObj = new JSONObject(response);
            JSONArray docs = kvizoviObj.getJSONArray("documents");
            for (int i = 0; i < docs.length(); i++) {
                ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                JSONObject docsObj = new JSONObject(docs.getString(i));
                String idKviza = docsObj.getString("name");
                String naziv = docsObj.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                String idKategorije = docsObj.getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");
                JSONArray kvizoviJSa = docsObj.getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");

                Log.w("IDIF", idKategorije);
                for (int k = 0; k < Data.getInstance().kategorije.size(); k++) {
                    if (idKategorije.contains(Data.getInstance().kategorije.get(k).getIdInFirebase())) {
                        katKviza = Data.getInstance().kategorije.get(k);
                    }
                }

                //TODO bug: dupla pitanja
                for (int j = 0; j < kvizoviJSa.length(); j++) {
                    JSONObject JSO = new JSONObject(kvizoviJSa.getString(j));
                    String imePitanja = JSO.getString("stringValue");

                    for (int k = 0; k < Data.getInstance().pitanja.size(); k++) {
                        if (imePitanja.contains(Data.getInstance().pitanja.get(k).getIdInFirebase())) {
                            Pitanje da = Data.getInstance().pitanja.get(k);
                            da.setKvizId(idKviza.substring(70));
                            kvizoviDBOpenHelper.spasiPitanje(da);
                            pitanjaUKvizu.add(da);
                        }
                    }

                }

                Kviz sad = new Kviz(naziv, pitanjaUKvizu, katKviza, idKviza.substring(70));
                sad.setKategorijaId(katKviza.getId());
                kvizoviDBOpenHelper.spasiKviz(sad);
                //Log.w("SUCCESS", "Kat kviza " + katKviza.getNaziv());
//                Data.getInstance().kvizovi.add(new Kviz(naziv, pitanjaUKvizu, katKviza, idKviza.substring(70)));
            }
        } catch (JSONException e) {
            Log.w("SUCCESS", "Kviz IOe! Value: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void spasiKategorijeUdatabase(ArrayList<Kategorija> kategorije) {
        //TODO provjeriti ako već imamo iste vrijednosti ne upisivati
        kvizoviDBOpenHelper.spasiKategorije(kategorije);
    }

    public void parsePitanja(String response) {
        JSONObject resObj;
        try {
            resObj = new JSONObject(response);
            JSONArray docs = resObj.getJSONArray("documents");
            Log.d("DATAdocsSize", String.valueOf(docs.length()));
            for (int i = 0; i < docs.length(); i++) {
                ArrayList<String> odgovori = new ArrayList<>();
                JSONObject jsonObject = new JSONObject(docs.getString(i));
                String idPit = jsonObject.getString("name").substring(70);
                String imePitanja = jsonObject.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                int indexTacnog = jsonObject.getJSONObject("fields").getJSONObject("indexTacnog").getInt("integerValue");
                JSONArray odgovoriJSA = jsonObject.getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                for (int j = 0; j < odgovoriJSA.length(); j++) {
                    JSONObject jObj = new JSONObject(odgovoriJSA.getString(j));
                    odgovori.add(jObj.getString("stringValue"));
                }

                for (int x = 0; x < odgovori.size(); x++) {
                    kvizoviDBOpenHelper.spasiOdgovor(idPit, odgovori.get(x));
                }

                // kvizovi ce spremiti pitanja, nemoj ovdje spremati
                //kvizoviDBOpenHelper.spasiPitanje(new Pitanje(imePitanja, imePitanja, odgovori, String.valueOf(indexTacnog), idPit));
                pitanja.add(new Pitanje(imePitanja, imePitanja, odgovori, String.valueOf(indexTacnog), idPit));
                Data.getInstance().pitanja.add(new Pitanje(imePitanja, imePitanja, odgovori, String.valueOf(indexTacnog), idPit));
                updateLayout();
            }
            //TODO upisati u bazu Pitanja i odgovore
        } catch (JSONException e) {
            Log.w("SUCCESS", "PIOe value: " + e.getMessage());
            e.printStackTrace();
        }

        getKvizovi();
    }

    private void populateFromDatabase() {
        Data.getInstance().kategorije.addAll(kvizoviDBOpenHelper.dobaviSveKategorije());
        Data.getInstance().pitanja.addAll(kvizoviDBOpenHelper.dobaviSvaPitanja());
        Data.getInstance().kvizovi.addAll(kvizoviDBOpenHelper.dobaviSveKvizove());
        updateLayout();
    }

    public void updateLayout() {
        FragmentManager fm = getSupportFragmentManager();
        FrameLayout lista = (FrameLayout) findViewById(R.id.listPlace);
        FrameLayout details = findViewById(R.id.detailPlace);

        kategorije.addAll(Data.getInstance().kategorije);

        if (ConnectivityHelper.isNetworkAvailable(getApplicationContext())) {
            kategorije.add(new Kategorija("Svi", "", ""));
        }

        Bundle bundle = new Bundle();
        bundle.putSerializable("kategorije", kategorije);

        if (lista != null) {
            listaFrag = new ListaFrag();
            listaFrag.setArguments(bundle);
            fm.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        kvizoviDBOpenHelper.close();
    }
}
