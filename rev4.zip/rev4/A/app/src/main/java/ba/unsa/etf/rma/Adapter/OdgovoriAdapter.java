package ba.unsa.etf.rma.Adapter;

import android.content.Context;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Pitanje;

public class OdgovoriAdapter extends ArrayAdapter {

    int resource;
    Context context;

    public OdgovoriAdapter(Context context, int resource, ArrayList<Pitanje> pitanja) {
        super(context, resource, pitanja);
        this.resource = resource;
        this.context = context;
    }
}
