package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    String naziv;
    String tekstPitanja;
    ArrayList<String> odgovori;
    String tacan;
    String idInFirebase;

    public String getKvizId() {
        return kvizId;
    }

    public void setKvizId(String kvizId) {
        this.kvizId = kvizId;
    }

    String kvizId;

    public Pitanje() {
        odgovori = new ArrayList<>();
    }

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan, String idInFirebase) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
        this.idInFirebase = idInFirebase;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public String getIdInFirebase() {
        return idInFirebase;
    }

    public void setIdInFirebase(String idInFirebase) {
        this.idInFirebase = idInFirebase;
    }

    public ArrayList<String> dajRandomOdgovore() {
        Collections.shuffle(this.odgovori);
        return odgovori;
    }
}
