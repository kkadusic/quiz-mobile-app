package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.textclassifier.TextClassification;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static java.lang.Math.round;

public class InformacijeFrag extends Fragment {

    TextView nazivKviza;
    TextView brojTacnihPitanja;
    TextView brojPreostalihPitanja;
    TextView procenatTacni;
    Button btnKraj;

    String naziv;
    String brojt;
    String brojp;
    String procenat;

    private Integer brojTacnih;
    private Integer brojPreostalih;
    private Integer brojOdgovorenih = 0;
    private Double procenatTacnih;

    public void azuriraj(Boolean tacan, int preostalo) {
        brojPreostalih = preostalo;

        brojOdgovorenih++;

        Log.d("SUCCESSinfo", String.valueOf(tacan));
        if (tacan) {
            brojTacnih++;
        }

        if (brojOdgovorenih != 0) {
            procenatTacnih = brojTacnih / (double) brojOdgovorenih;
        } else {
            procenatTacnih = 0.;
        }


        setTekst(brojTacnih, brojPreostalih, procenatTacnih);
    }

    public String dajProcTacnih(){
        return String.valueOf(new DecimalFormat("0.00").format(procenatTacnih*100));
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_informacije, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        nazivKviza = getView().findViewById(R.id.infNazivKviza);
        brojTacnihPitanja = getView().findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihPitanja = getView().findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacni = getView().findViewById(R.id.infProcenatTacni);
        btnKraj = getView().findViewById(R.id.btnKraj);

        naziv = getArguments().getString("Naziv");
        brojt = getArguments().getString("BrojT");
        brojp = getArguments().getString("BrojP");
        procenat = getArguments().getString("PT");

        brojTacnih = Integer.parseInt(brojt);
        brojPreostalih = Integer.parseInt(brojp);
        procenatTacnih = Double.parseDouble(procenat);

        nazivKviza.setText(naziv);
        setTekst(brojTacnih, brojPreostalih, procenatTacnih);

        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((IgrajKvizAkt) getActivity()).endAkt();
            }
        });

    }

    public void setTekst(Integer brojTacnih, Integer brojPreostalih, Double procenatTacnih) {
        procenatTacnih *= 100;
        brojPreostalihPitanja.setText(brojPreostalih.toString());
        brojTacnihPitanja.setText(brojTacnih.toString());
        procenatTacni.setText(procenatTacnih.toString() + "%");
    }

    public void setTekstPrazno() {
        brojPreostalihPitanja.setText("");
        brojTacnihPitanja.setText("");
        procenatTacni.setText("");
    }

}
