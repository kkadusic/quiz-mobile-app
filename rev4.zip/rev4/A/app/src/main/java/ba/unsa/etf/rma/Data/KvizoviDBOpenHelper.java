package ba.unsa.etf.rma.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;


//POGLEDATI linkove za primjere:
//https://guides.codepath.com/android/local-databases-with-sqliteopenhelper
//https://www.androidhive.info/2013/09/android-sqlite-database-with-multiple-tables/


public class KvizoviDBOpenHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "kvizovi.db";
    public static final int DATABASE_VERSION = 1;
    public static final String TAG = SQLiteOpenHelper.class.getSimpleName();

    public KvizoviDBOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TabelaKvizova.TABLE_CREATE);
        sqLiteDatabase.execSQL(TabelaKategorija.TABLE_CREATE);
        sqLiteDatabase.execSQL(TabelaPitanja.TABLE_CREATE);
        sqLiteDatabase.execSQL(TabelaOdgovora.TABLE_CREATE);
        sqLiteDatabase.execSQL(TabelaRangova.TABLE_CREATE);
        sqLiteDatabase.execSQL(TabelaRangListi.TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists " + TabelaKvizova.TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TabelaKategorija.TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TabelaPitanja.TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TabelaOdgovora.TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TabelaRangova.TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TabelaRangListi.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public static class TabelaKvizova {
        public static final String TABLE_NAME = "kvizovi";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_NAZIV = "naziv";
        public static final String COLUMN_KATEGORIJA_ID = "kategorija_id";
        public static final String COLUMN_ID_IN_FIREBASE = "idInFirebase";
        //lista pitanja je ubačena u tabelu pitanja
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + "  text primary key, "
                + COLUMN_NAZIV + " text not null, "
                + COLUMN_KATEGORIJA_ID + " integer not null, "
                + COLUMN_ID_IN_FIREBASE + " text not null"
                + ");";
    }

    public static class TabelaKategorija {
        public static final String TABLE_NAME = "kategorije";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_NAZIV = "naziv";
        public static final String COLUMN_ID_IN_FIREBASE = "idInFirebase";
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + " integer primary key, "
                + COLUMN_NAZIV + " text not null unique, "
                + COLUMN_ID_IN_FIREBASE + " text not null"
                + ");";
    }

    public static class TabelaPitanja {
        public static final String TABLE_NAME = "pitanja";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_NAZIV = "naziv";
        public static final String COLUMN_TEKST_PITANJA = "tekstPitanja";
        public static final String COLUMN_TACAN = "tacan";
        public static final String COLUMN_ID_IN_FIREBASE = "idInFirebase";
        //lista odgovora je ubačena u tabelu odgovori
        public static final String COLUMN_KVIZ_ID = "kviz_id";
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + " integer primary key autoincrement, "
                + COLUMN_NAZIV + " text not null, "
                + COLUMN_TEKST_PITANJA + " text not null, "
                + COLUMN_TACAN + " text not null, "
                + COLUMN_ID_IN_FIREBASE + " text not null, "
                + COLUMN_KVIZ_ID + " integer not null"
                + ");";
    }

    public static class TabelaOdgovora {
        public static final String TABLE_NAME = "odgovori";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_PITANJE_ID = "pitanje_id";
        public static final String COLUMN_ODGOVOR = "odgovor";
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + " integer primary key autoincrement, "
                + COLUMN_PITANJE_ID + " integer not null, "
                + COLUMN_ODGOVOR + " text not null"
                + ");";

    }

    public static class TabelaRangova {
        public static final String TABLE_NAME = "rangovi";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_POZICIJA = "pozicija";
        public static final String COLUMN_IME_IGRACA = "imeIgraca";
        public static final String COLUMN_PROCENAT_TACNIH = "procenatTacnih";
        public static final String COLUMN_KVIZ_ID = "kviz_id";
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + " integer primary key autoincrement, "
                + COLUMN_POZICIJA + " text not null, "
                + COLUMN_IME_IGRACA + " text not null, "
                + COLUMN_PROCENAT_TACNIH + " text not null, "
                + COLUMN_KVIZ_ID + " integer not null"
                + ");";
    }

    //Provjeriti, ova tabela vjerovatno ne treba jer se lang lista vodi u tabeliRangova
    public static class TabelaRangListi {
        public static final String TABLE_NAME = "rangLista";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_NAZIV = "nazivKviza";
        //lista rangova je
        public static final String TABLE_CREATE = "create table "
                + TABLE_NAME + "("
                + COLUMN_ID + " integer primary key autoincrement, "
                + COLUMN_NAZIV + " text not null"
                + ");";
    }

    public List<Kviz> dobaviSveKvizove() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.query(TabelaKvizova.TABLE_NAME, null, null, null, null, null, null);
        List<Kviz> kvizovi = new ArrayList<>();
        try {
            while (cursor.moveToNext()) {
                Kviz kviz = new Kviz();
                kviz.setNaziv(cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_NAZIV)));
                int katId = cursor.getInt(cursor.getColumnIndex(TabelaKvizova.COLUMN_KATEGORIJA_ID));
                kviz.setKategorija(dobaviKategoriju(katId));
                kviz.setIdInFirebase(cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_ID_IN_FIREBASE)));
                kviz.setKategorijaId(String.valueOf(katId));
                String kvizId = cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_ID));
                kviz.setId(kvizId);
                kviz.setPitanja(dobaviPitanjaZaKviz(kvizId));
                kvizovi.add(kviz);
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return kvizovi;
    }

    public Kategorija dobaviKategoriju(int idKategorije) {
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = new String[]{Integer.toString(idKategorije)};
        Cursor cursor = db.query(TabelaKategorija.TABLE_NAME, null, TabelaKategorija.COLUMN_ID + "=?", selectionArgs, null, null, null);
        Kategorija kategorija = new Kategorija();
        try {
            while (cursor.moveToNext()) {
                kategorija.setId(cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_ID)));
                kategorija.setNaziv(cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_NAZIV)));
                kategorija.setIdInFirebase(cursor.getString(cursor.getColumnIndex(TabelaKvizova.COLUMN_ID_IN_FIREBASE)));
                //TODO provjeriti relaciju id u klasi i id u bazi i implementirati, da li su isti ili se odnosi na nešto drugo?
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return kategorija;
    }

    public void spasiKategorije(ArrayList<Kategorija> kategorije) {
        if (kategorije == null || kategorije.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        for (Kategorija kategorija : kategorije) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(TabelaKategorija.COLUMN_ID, kategorija.getId());
            contentValues.put(TabelaKategorija.COLUMN_NAZIV, kategorija.getNaziv());
            contentValues.put(TabelaKategorija.COLUMN_ID_IN_FIREBASE, kategorija.getIdInFirebase());
            //TODO provjeriti relaciju id u klasi i id u bazi i implementirati, da li su isti ili se odnosi na nešto drugo?
            //TODO provjeriti zasto ne replacea duplikate vec snima ponovo iako je name unique
            db.insertWithOnConflict(TabelaKategorija.TABLE_NAME, null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
//            db.insert(TabelaKategorija.TABLE_NAME, null, contentValues);
        }
    }

    public void spasiKviz(Kviz kviz) {
        if (kviz == null) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TabelaKvizova.COLUMN_NAZIV, kviz.getNaziv());
        contentValues.put(TabelaKvizova.COLUMN_ID, kviz.getIdInFirebase());
        contentValues.put(TabelaKvizova.COLUMN_ID_IN_FIREBASE, kviz.getIdInFirebase());
        contentValues.put(TabelaKvizova.COLUMN_KATEGORIJA_ID, kviz.getKategorijaId());
        db.insertWithOnConflict(TabelaKvizova.TABLE_NAME, null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
    }

    //TODO
    public ArrayList<Pitanje> dobaviPitanjaZaKviz(String idKviza) {
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = new String[]{idKviza};
        Cursor cursor = db.query(TabelaPitanja.TABLE_NAME, null, TabelaPitanja.COLUMN_KVIZ_ID + "=?", selectionArgs, null, null, null);
        try {
            while (cursor.moveToNext()) {
                Pitanje pitanje = new Pitanje();
                pitanje.setKvizId(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_KVIZ_ID)));
                pitanje.setIdInFirebase(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_ID_IN_FIREBASE)));
                pitanje.setNaziv(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_NAZIV)));
                pitanje.setTacan(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_TACAN)));
                pitanje.setTekstPitanja(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_TEKST_PITANJA)));
                pitanje.setOdgovori(dobaviOdgovoreZaPitanje(pitanje.getIdInFirebase()));
                pitanja.add(pitanje);
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return pitanja;
    }

    public List<Kategorija> dobaviSveKategorije() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.query(TabelaKategorija.TABLE_NAME, null, null, null, null, null, null);
        List<Kategorija> kategorije = new ArrayList<>();
        try {
            while (cursor.moveToNext()) {
                Kategorija kategorija = new Kategorija();
                //TODO provjeriti relaciju id u klasi i id u bazi i implementirati, da li su isti ili se odnosi na nešto drugo?
                kategorija.setNaziv(cursor.getString(cursor.getColumnIndex(TabelaKategorija.COLUMN_NAZIV)));
                kategorija.setId(cursor.getString(cursor.getColumnIndex(TabelaKategorija.COLUMN_ID)));
                kategorija.setIdInFirebase(cursor.getString(cursor.getColumnIndex(TabelaKategorija.COLUMN_ID_IN_FIREBASE)));
                kategorije.add(kategorija);
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return kategorije;
    }

    public List<Pitanje> dobaviSvaPitanja() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.query(TabelaPitanja.TABLE_NAME, null, null, null, null, null, null);
        List<Pitanje> pitanja = new ArrayList<>();
        try {
            while (cursor.moveToNext()) {
                Pitanje pitanje = new Pitanje();
                pitanje.setNaziv(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_NAZIV)));
                pitanje.setTekstPitanja(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_TEKST_PITANJA)));
                pitanje.setTacan(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_TACAN)));
                String pitanjeId = cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_ID));
                pitanje.setOdgovori(dobaviOdgovoreZaPitanje(pitanjeId));
                pitanje.setIdInFirebase(cursor.getString(cursor.getColumnIndex(TabelaPitanja.COLUMN_ID_IN_FIREBASE)));
                pitanja.add(pitanje);
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return pitanja;
    }

    public void spasiPitanje(Pitanje pitanje) {
        if (pitanje == null) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TabelaPitanja.COLUMN_NAZIV, pitanje.getNaziv());
        contentValues.put(TabelaPitanja.COLUMN_ID_IN_FIREBASE, pitanje.getIdInFirebase());
        contentValues.put(TabelaPitanja.COLUMN_TACAN, pitanje.getTacan());
        contentValues.put(TabelaPitanja.COLUMN_TEKST_PITANJA, pitanje.getTekstPitanja());
        contentValues.put(TabelaPitanja.COLUMN_KVIZ_ID, pitanje.getKvizId());
        db.insertWithOnConflict(TabelaPitanja.TABLE_NAME, null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public void spasiOdgovor(String pitanjeId, String odgovor) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TabelaOdgovora.COLUMN_ODGOVOR, odgovor);
        contentValues.put(TabelaOdgovora.COLUMN_PITANJE_ID, pitanjeId);
        db.insertWithOnConflict(TabelaOdgovora.TABLE_NAME, null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
    }

    //TODO
    public ArrayList<String> dobaviOdgovoreZaPitanje(String idPitanja) {
        ArrayList<String> odgovori = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = new String[]{idPitanja};
        Cursor cursor = db.query(TabelaOdgovora.TABLE_NAME, null, TabelaOdgovora.COLUMN_PITANJE_ID + "=?", selectionArgs, null, null, null);
        try {
            while (cursor.moveToNext()) {
                odgovori.add(cursor.getString(cursor.getColumnIndex(TabelaOdgovora.COLUMN_ODGOVOR)));
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get items from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return odgovori;
    }

}
