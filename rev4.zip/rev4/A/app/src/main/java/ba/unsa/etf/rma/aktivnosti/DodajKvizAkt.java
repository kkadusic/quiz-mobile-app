package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import ba.unsa.etf.rma.Adapter.PitanjeAdapter;
import ba.unsa.etf.rma.Adapter.SpinnerKategorijaAdapter;
import ba.unsa.etf.rma.Async.PostRequestAsync;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.token;


public class DodajKvizAkt extends AppCompatActivity {

    ArrayList<Kategorija> kategorije;
    ArrayList<Pitanje> pitanjaDodana;
    ArrayList<Pitanje> pitanjaMoguca;
    Kviz kviz;

    EditText editText;
    Spinner spinner;
    ListView listViewDodana;
    ListView listViewMoguca;

    PitanjeAdapter pitanjeAdapterDodana;
    PitanjeAdapter pitanjeAdapterMoguca;
    SpinnerKategorijaAdapter spinnerKategorijaAdapter;

    Button btnImportKviz;

    int kvizPosition;
    //boolean spinnerTest = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        spinner = findViewById(R.id.spKategorije);
        editText = findViewById(R.id.etNaziv);
        listViewDodana = findViewById(R.id.lvDodanaPitanja);
        listViewMoguca = findViewById(R.id.lvMogucaPitanja);
        Button button = findViewById(R.id.btnDodajKviz);
        Button btnImportKviz = findViewById(R.id.btnImportKviz);

        kategorije = new ArrayList<>();
        pitanjaDodana = new ArrayList<>();
        pitanjaMoguca = new ArrayList<>();

        kvizPosition = getIntent().getExtras().getInt("kvizPosition");

        if (kvizPosition == Data.getInstance().kvizovi.size()) {
            pitanjaDodana = new ArrayList<>();
            kviz = new Kviz();
        } else {
            kviz = Data.getInstance().kvizovi.get(kvizPosition);
            pitanjaDodana.addAll(kviz.getPitanja());
            editText.setText(kviz.getNaziv());
        }

        pitanjaMoguca.addAll(Data.getInstance().pitanja);
        for (int i = 0; i < pitanjaDodana.size(); i++) {
            pitanjaMoguca.remove(pitanjaDodana.get(i));
        }
        //pitanjeAdapterMoguca.notifyDataSetChanged();

        pitanjaDodana.add(new Pitanje("Dodaj pitanje", "Dodaj pitanje", new ArrayList<String>(), "", ""));

        kategorije.addAll(Data.getInstance().kategorije);
        kategorije.add(new Kategorija("Dodaj kategoriju", "", ""));

        spinnerKategorijaAdapter = new SpinnerKategorijaAdapter(this, android.R.layout.simple_list_item_1, kategorije);
        spinner.setAdapter(spinnerKategorijaAdapter);

        pitanjeAdapterDodana = new PitanjeAdapter(this, android.R.layout.simple_list_item_1, pitanjaDodana);
        listViewDodana.setAdapter(pitanjeAdapterDodana);

        pitanjeAdapterMoguca = new PitanjeAdapter(this, android.R.layout.simple_list_item_1, pitanjaMoguca);
        listViewMoguca.setAdapter(pitanjeAdapterMoguca);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == kategorije.size() - 1 /*&& spinnerTest*/) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(intent, 100);
                }
                //spinnerTest = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        listViewDodana.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == pitanjaDodana.size() - 1) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    startActivityForResult(intent, 100);
                } else {
                    pitanjaMoguca.add(pitanjaDodana.remove(position));
                }
                pitanjeAdapterDodana.notifyDataSetChanged();
                pitanjeAdapterMoguca.notifyDataSetChanged();
            }
        });

        listViewMoguca.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pitanjaDodana.remove(pitanjaDodana.size() - 1);
                pitanjaDodana.add(pitanjaMoguca.remove(position));
                pitanjaDodana.add(new Pitanje("Dodaj pitanje", "Dodaj pitanje", new ArrayList<String>(), "", ""));
                pitanjeAdapterDodana.notifyDataSetChanged();
                pitanjeAdapterMoguca.notifyDataSetChanged();
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean test = false;
                if ((kviz.getNaziv() == null || kviz.getNaziv().equals("")) && (editText.getText() == null || editText.getText().toString().equals(""))) {
                    editText.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    if (pitanjaDodana.size() == 1) {
                        listViewDodana.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        listViewDodana.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    }
                } else {
                    editText.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    if (pitanjaDodana.size() == 1) {
                        listViewDodana.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        listViewDodana.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                        test = true;
                    }
                }
                if (test) {
                    kviz.setNaziv(editText.getText().toString());
                    kviz.setKategorija((Kategorija) spinner.getSelectedItem());
                    pitanjaDodana.remove(pitanjaDodana.size() - 1);
                    kviz.setPitanja(pitanjaDodana);
                    boolean isUpdate;
                    if (kvizPosition == Data.getInstance().kvizovi.size()) {
                        Data.getInstance().kvizovi.add(kviz);
                        isUpdate = false;
                    } else {
                        Data.getInstance().kvizovi.get(kvizPosition).setNaziv(kviz.getNaziv());
                        Data.getInstance().kvizovi.get(kvizPosition).setPitanja(kviz.getPitanja());
                        Data.getInstance().kvizovi.get(kvizPosition).setKategorija(kviz.getKategorija());
                        isUpdate = true;
                    }
                    String pitanja = "";
                    for (int i = 0; i < kviz.getPitanja().size(); i++) {
                        pitanja = pitanja + "{\"stringValue\":\"" + kviz.getPitanja().get(i).getIdInFirebase() + "\"}";
                        if (i != kviz.getPitanja().size() - 1) pitanja = pitanja + ",";
                    }
                    //Log.d("PRA pitanja", pitanja);

                    if (!isUpdate) {
                        String data = "{\"fields\":{\"pitanja\":{\"arrayValue\":{\"values\":[" + pitanja + "]}}, \"naziv\":{\"stringValue\":\"" + kviz.getNaziv() + "\"}, \"idKategorije\":{\"stringValue\":\"" + kviz.getKategorija().getIdInFirebase() + "\"}}}";
                        new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kvizovi?access_token=" + token, data, "POST");
                    }

                    if (isUpdate) {
                        String data = "{\"fields\":{\"pitanja\":{\"arrayValue\":{\"values\":[" + pitanja + "]}}, \"naziv\":{\"stringValue\":\"" + kviz.getNaziv() + "\"}, \"idKategorije\":{\"stringValue\":\"" + kviz.getKategorija().getIdInFirebase() + "\"}}}";
                        new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kvizovi/" + kviz.getIdInFirebase() + "?access_token=" + token, data, "PATCH");
                    }

                    finish();
                }
            }
        });

        btnImportKviz.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("text/plain");
                startActivityForResult(intent, 678);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100) {
            if (resultCode == 101) {
                Pitanje pitanje = (Pitanje) data.getSerializableExtra("pitanje");
                if (pitanje != null) {
                    pitanjaDodana.remove(pitanjaDodana.size() - 1);
                    pitanjaDodana.add(pitanje);
                    pitanjaDodana.add(new Pitanje("Dodaj pitanje", "Dodaj pitanje", new ArrayList<String>(), "", ""));
                    pitanjeAdapterDodana.notifyDataSetChanged();
                }
            } else if (resultCode == 102) {
                kategorije.clear();
                kategorije.addAll(Data.getInstance().kategorije);
                kategorije.add(new Kategorija("Dodaj kategoriju", "", ""));
                spinnerKategorijaAdapter.notifyDataSetChanged();
                spinnerKategorijaAdapter.notifyDataSetChanged();
            }
        }


        if (requestCode == 678 && resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            if (data != null) {
                uri = data.getData();
                try {
                    String importovaniKviz = readTextFromUri(uri);
                    Log.e("a", "ovo je kontekst:" + importovaniKviz);
                    String[] content = importovaniKviz.split("£");
                    int size = content.length;
                    Log.e("b:", "Velicina: " + content.length);
                    String[] items = {};

                    items = content[0].split(","); //promijeni kasnije..


                    Log.e("c:", "Velicina2: " + items.length);
                    for (int i = 0; i < Data.getInstance().kvizovi.size(); i++) {
                        if (Data.getInstance().kvizovi.get(i).getNaziv().equals(items[0])) {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                            alertDialogBuilder.setTitle("Poruka za naziv kviza");
                            alertDialogBuilder.setMessage("Kviz kojeg importujete vec postoji!");
                            alertDialogBuilder.setNegativeButton(android.R.string.no, null);
                            alertDialogBuilder.setIcon(android.R.drawable.ic_dialog_alert);
                            alertDialogBuilder.show();
                            return;
                        }
                    }
                    if (content.length - 1 != Integer.parseInt(items[2])) {
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                        alertDialogBuilder.setTitle("Poruka za broj pitanja");
                        alertDialogBuilder.setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!");
                        alertDialogBuilder.setNegativeButton(android.R.string.no, null);
                        alertDialogBuilder.setIcon(android.R.drawable.ic_dialog_alert);
                        alertDialogBuilder.show();
                        return;
                    }
                    boolean test = false;
                    for (int i = 0; i < Data.getInstance().kategorije.size(); i++) {
                        if (Data.getInstance().kategorije.get(i).getNaziv().equals(items[1])) {
                            test = true;
                            spinner.setSelection(i);
                        }
                    }
                    if (!test) {
                        Data.getInstance().kategorije.add(new Kategorija(items[1], "0", ""));
                        kategorije.remove(kategorije.size() - 1);
                        kategorije.add(new Kategorija(items[1], "0", ""));
                        kategorije.add(new Kategorija("Dodaj kategoriju", "", ""));
                        spinnerKategorijaAdapter.notifyDataSetChanged();
                        spinner.setSelection(kategorije.size() - 2);
                    }


                    for (int i = 1; i < content.length; i++) {
                        int brojac = 0;
                        String[] odgovori = content[i].split(",");
                        for (int j = 3; j < odgovori.length; j++) brojac++;
                        if (brojac > Integer.parseInt(odgovori[1]) || brojac < Integer.parseInt(odgovori[1])) {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                            alertDialogBuilder.setTitle("Poruka za broj odgovora");
                            alertDialogBuilder.setMessage("Kviz kojeg imporujete ima neispravan broj odgovora!");
                            alertDialogBuilder.setNegativeButton(android.R.string.no, null);
                            alertDialogBuilder.setIcon(android.R.drawable.ic_dialog_alert);
                            alertDialogBuilder.show();
                            return;
                        }
                    }

                    for (int i = 1; i < content.length; i++) {
                        int brojac = 0;
                        String[] odgovori = content[i].split(",");
                        for (int j = 3; j < odgovori.length; j++) brojac++;
                        if (brojac < Integer.parseInt(odgovori[2])) {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                            alertDialogBuilder.setTitle("Poruka za tacan odgovor");
                            alertDialogBuilder.setMessage("Kviz kojeg imporujete ima neispravan index tacnog odgovora!");
                            alertDialogBuilder.setNegativeButton(android.R.string.no, null);
                            alertDialogBuilder.setIcon(android.R.drawable.ic_dialog_alert);
                            alertDialogBuilder.show();
                            return;
                        }
                    }

                    editText.setText(items[0]);

                    boolean test2 = false;

                    outerloop:
                    for (int i = 0; i < pitanjaDodana.size(); i++) {
                        for (int j = 1; j < content.length; j++) {
                            String[] dodanaPitanja = content[j].split(",");
                            for (int k = 3; k < dodanaPitanja.length; k++) {
                                for (int s = 0; s < pitanjaDodana.get(i).getOdgovori().size(); s++) {
                                    if (pitanjaDodana.get(i).getOdgovori().get(s).equals(dodanaPitanja[k])) {
                                        test2 = true;
                                        break outerloop;
                                    }
                                }
                            }
                        }
                    }

                    outerloop:
                    for (int i = 0; i < pitanjaMoguca.size(); i++) {
                        for (int j = 1; j < content.length; j++) {
                            String[] dodanaPitanja = content[j].split(",");
                            for (int k = 3; k < dodanaPitanja.length; k++) {
                                for (int s = 0; s < pitanjaMoguca.get(i).getOdgovori().size(); s++) {
                                    if (pitanjaMoguca.get(i).getOdgovori().get(s).equals(dodanaPitanja[k])) {
                                        test2 = true;
                                        break outerloop;
                                    }
                                }
                            }
                        }
                    }

                    if (!test2) {
                        for (int i = 1; i < content.length; i++) {
                            String[] dodanaPitanja = content[i].split(",");
                            ArrayList<String> odgovori = new ArrayList<>(Arrays.asList(dodanaPitanja).subList(3, dodanaPitanja.length));
                            pitanjaDodana.add(new Pitanje(dodanaPitanja[0], dodanaPitanja[0], odgovori, dodanaPitanja[Integer.parseInt(dodanaPitanja[2])], ""));
                        }
                        pitanjeAdapterDodana.notifyDataSetChanged();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private String readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append("£");
        }
        reader.close();
        assert inputStream != null;
        inputStream.close();
        return stringBuilder.toString();
    }
}